# Inventaire de la banque de questions

Fichier **généré** par `python -m app.contenu inventaire` (depuis `api/`) : ne pas modifier à la main.

- Chapitres : **164** · compétences : **367** · questions actives : **1927**
- Validation pédagogique : 0 validée(s), 1927 à valider, 0 à corriger

## Matrice de couverture

Nombre de questions actives par difficulté (1 = application directe … 5 = niveau bac). ⚠ signale un trou : une difficulté sans question, ou une compétence sans cours.

### 6e — Tronc commun

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Nombres entiers et décimaux | `6E-NUMERATION` Écrire et décomposer un nombre décimal | ✓ | 2 | 1 | 1 | 1 | 1 | 6 | 6 |
| 1. Nombres entiers et décimaux | `6E-COMPARER-DEC` Repérer, comparer, encadrer et arrondir des nombres décimaux | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Calculer avec les nombres décimaux | `6E-ADD-MULT` Additionner, soustraire et multiplier des nombres décimaux | ✓ | 2 | 1 | 2 | 1 | 1 | 7 | 7 |
| 2. Calculer avec les nombres décimaux | `6E-DIVISION` Effectuer des divisions euclidiennes et décimales | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 3. Les fractions | `6E-FRAC-SENS` Comprendre une fraction comme un quotient | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 3. Les fractions | `6E-FRAC-CALCUL` Comparer et calculer avec des fractions | ✓ | 1 | 2 | 2 | 1 | 1 | 7 | 7 |
| 4. Proportionnalité et pourcentages | `6E-PROP` Reconnaître et résoudre un problème de proportionnalité | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Proportionnalité et pourcentages | `6E-POURCENT` Comprendre et appliquer un pourcentage | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. Pensée algébrique et motifs | `6E-PREALG` Résoudre des problèmes à nombre inconnu et étudier des motifs évolutifs | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Longueurs, aires, volumes et durées | `6E-PERIMETRES` Convertir des longueurs et calculer des périmètres | ✓ | 2 | 1 | 1 | 1 | 1 | 6 | 6 |
| 6. Longueurs, aires, volumes et durées | `6E-AIRES-VOLUMES` Calculer des aires et des volumes, convertir des aires | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 6. Longueurs, aires, volumes et durées | `6E-DUREES` Calculer avec des horaires et des durées | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 7. Géométrie plane et vision dans l’espace | `6E-CERCLE-MEDIATRICE` Utiliser distances, milieu, cercle et médiatrice | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 7. Géométrie plane et vision dans l’espace | `6E-ANGLES-TRIANGLES` Mesurer des angles et utiliser les propriétés des triangles | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 7. Géométrie plane et vision dans l’espace | `6E-SYMETRIE` Construire le symétrique d’une figure par rapport à une droite | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 8. Données et probabilités | `6E-TABLEAUX` Recueillir, organiser et lire des données | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Données et probabilités | `6E-PROBAS` Calculer des probabilités simples | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 9. Initiation à la pensée informatique | `6E-INSTRUCTIONS` Exécuter et produire une séquence d’instructions | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 6e — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de CM2 | `6E-DIAG-NUMERATION` Comprendre les entiers et les décimaux (acquis de CM2) | — | 2 | 1 | 2 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de CM2 | `6E-DIAG-CALCUL` Calculer avec les quatre opérations (acquis de CM2) | — | 1 | 2 | — | — | — | 3 | 3 |
| 90. Diagnostic d'entrée, acquis de CM2 | `6E-DIAG-FRACTIONS` Utiliser des fractions simples (acquis de CM2) | — | — | 2 | — | — | — | 2 | 2 |
| 90. Diagnostic d'entrée, acquis de CM2 | `6E-DIAG-PROPORTIONNALITE` Résoudre des problèmes de proportionnalité et de comparaison (acquis de CM2) | — | — | 3 | 1 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de CM2 | `6E-DIAG-GRANDEURS-GEOMETRIE` Mesures, périmètres, aires et constructions (acquis de CM2) | — | 1 | 3 | — | — | — | 4 | 4 |

### 5e — Tronc commun

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Opérations, priorités et divisibilité | `5E-PRIORITES` Enchaîner des opérations en respectant les priorités | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Opérations, priorités et divisibilité | `5E-DIVISIBILITE` Utiliser multiples, diviseurs et critères de divisibilité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Nombres relatifs | `5E-RELATIFS-REPERER` Repérer et comparer des nombres relatifs | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Nombres relatifs | `5E-RELATIFS-CALCUL` Additionner et soustraire des nombres relatifs | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 3. Nombres rationnels et fractions | `5E-FRAC-COMPARER` Écrire autrement et comparer des fractions | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Nombres rationnels et fractions | `5E-FRAC-ADDITION` Additionner et soustraire des fractions | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Puissances et calcul littéral | `5E-PUISSANCES` Calculer avec des carrés et des cubes | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Puissances et calcul littéral | `5E-EXPRESSIONS` Produire et transformer des expressions littérales | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Puissances et calcul littéral | `5E-EQUATIONS` Modéliser et résoudre des équations simples | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Repérage, solides et volumes | `5E-REPERAGE` Se repérer sur une droite graduée et dans un repère du plan | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. Repérage, solides et volumes | `5E-SOLIDES` Représenter des solides et calculer des volumes | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Symétrie centrale et angles | `5E-SYM-CENTRALE` Construire et utiliser le symétrique par un demi-tour | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Symétrie centrale et angles | `5E-ANGLES-PARALLELES` Caractériser le parallélisme par les angles | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Triangles et parallélogrammes | `5E-TRIANGLES` Construire des triangles et utiliser leurs droites remarquables | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 7. Triangles et parallélogrammes | `5E-PARALLELOGRAMMES` Reconnaître et utiliser les parallélogrammes | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 8. Statistiques et probabilités | `5E-STATISTIQUES` Recueillir, représenter et résumer des données | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |
| 8. Statistiques et probabilités | `5E-PROBABILITES` Calculer des probabilités en situation d’équiprobabilité | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 9. Proportionnalité et premières fonctions | `5E-PROPORTIONNALITE` Reconnaître et résoudre des situations de proportionnalité | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 9. Proportionnalité et premières fonctions | `5E-FONCTIONS` Passer d’un mode de représentation d’une relation à un autre | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Algorithmique et programmation | `5E-PROGRAMMES` Écrire et exécuter des programmes avec boucles, conditions et variables | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |

### 5e — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de 6e | `5E-DIAG-DECIMAUX` Calculer avec les nombres décimaux (acquis de 6e) | — | 1 | 2 | 1 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 6e | `5E-DIAG-FRACTIONS` Comprendre et utiliser les fractions (acquis de 6e) | — | 1 | 2 | — | — | — | 3 | 3 |
| 90. Diagnostic d'entrée, acquis de 6e | `5E-DIAG-PROPORTIONNALITE` Proportionnalité, pourcentages et choix d'un modèle (acquis de 6e) | — | 1 | 1 | 2 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 6e | `5E-DIAG-GRANDEURS` Durées, aires, volumes et raisonnement sur les grandeurs (acquis de 6e) | — | — | 3 | 1 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 6e | `5E-DIAG-GEOMETRIE` Symétrie axiale et constructions (acquis de 6e) | — | — | 2 | — | — | — | 2 | 2 |

### 4e — Tronc commun

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Puissances, notation scientifique et racines carrées | `4E-PUISSANCES` Calculer avec les puissances et la notation scientifique | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Puissances, notation scientifique et racines carrées | `4E-RACINES` Connaître et utiliser la racine carrée d’un nombre positif | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Nombres relatifs et nombres rationnels | `4E-RELATIFS-PRODUITS` Multiplier et diviser des nombres relatifs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Nombres relatifs et nombres rationnels | `4E-FRACTIONS-CALCUL` Calculer et comparer avec des nombres rationnels | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Divisibilité et nombres premiers | `4E-NOMBRES-PREMIERS` Décomposer en facteurs premiers et simplifier des fractions | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Calcul littéral et équations | `4E-DISTRIBUTIVITE` Développer, factoriser et réduire avec la distributivité simple | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Calcul littéral et équations | `4E-EQUATIONS` Mettre en équation et résoudre une équation du premier degré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Pythagore, Thalès et cosinus | `4E-PYTHAGORE` Utiliser le théorème de Pythagore et sa réciproque | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Pythagore, Thalès et cosinus | `4E-THALES` Utiliser le théorème de Thalès dans des triangles emboîtés | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Pythagore, Thalès et cosinus | `4E-COSINUS` Utiliser le cosinus d’un angle aigu dans un triangle rectangle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Translations, agrandissements et réductions | `4E-TRANSLATION` Transformer une figure par translation | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Translations, agrandissements et réductions | `4E-AGRANDISSEMENT` Agrandir ou réduire une figure et calculer longueurs, aires, volumes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Pyramides, cônes et grandeurs composées | `4E-PYRAMIDE-CONE` Se repérer dans l’espace et calculer le volume d’une pyramide, d’un cône | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Pyramides, cônes et grandeurs composées | `4E-GRANDEURS-COMPOSEES` Calculer avec des grandeurs composées et convertir leurs unités | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Statistiques et probabilités | `4E-MEDIANE` Représenter des données et calculer une médiane | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Statistiques et probabilités | `4E-PROBABILITES` Calculer des probabilités et utiliser l’événement contraire | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Proportionnalité et notion de fonction | `4E-PROPORTIONNALITE` Résoudre des problèmes de proportionnalité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Proportionnalité et notion de fonction | `4E-FONCTIONS` Représenter la dépendance de deux grandeurs par une formule ou un graphique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Algorithmique et programmation | `4E-PROGRAMMES` Écrire, mettre au point et exécuter un programme | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 4e — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-RELATIFS` Additionner et soustraire des relatifs, respecter les priorités (acquis de 5e) | — | 1 | 2 | 1 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-FRACTIONS` Comparer et additionner des fractions, fraction d'une quantité (acquis de 5e) | — | — | 2 | 1 | — | — | 3 | 3 |
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-LITTERAL` Produire et utiliser une expression littérale (acquis de 5e) | — | 1 | 1 | 1 | — | — | 3 | 3 |
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-PROPORTIONNALITE` Pourcentages et échelles (acquis de 5e) | — | — | 1 | 1 | — | — | 2 | 2 |
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-GEOMETRIE` Triangles, symétrie centrale et parallélogrammes (acquis de 5e) | — | 1 | 3 | 1 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de 5e | `4E-DIAG-DONNEES` Moyenne et probabilités simples (acquis de 5e) | — | 1 | 2 | — | — | — | 3 | 3 |

### 3e — Tronc commun

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Arithmétique et calcul numérique | `3E-ARITHMETIQUE` Décomposer, simplifier et résoudre des problèmes de divisibilité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Arithmétique et calcul numérique | `3E-CALCUL-NUMERIQUE` Résoudre des problèmes avec fractions, racines et puissances | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Calcul littéral, identités et équations | `3E-DEVELOPPER` Développer, factoriser et utiliser l’identité $a^2 - b^2$ | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 2. Calcul littéral, identités et équations | `3E-EQUATIONS` Résoudre des équations du premier degré, produits et $x^2 = a$ | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Fonctions, fonctions linéaires et affines | `3E-NOTION-FONCTION` Utiliser le vocabulaire des fonctions, déterminer images et antécédents | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Fonctions, fonctions linéaires et affines | `3E-FONCTIONS-AFFINES` Représenter et interpréter fonctions linéaires et affines | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |
| 4. Thalès, triangles semblables, trigonométrie et transformations | `3E-THALES-SEMBLABLES` Utiliser Thalès (configuration papillon) et les triangles semblables | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Thalès, triangles semblables, trigonométrie et transformations | `3E-TRIGONOMETRIE` Utiliser cosinus, sinus et tangente dans le triangle rectangle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Thalès, triangles semblables, trigonométrie et transformations | `3E-ROTATION-HOMOTHETIE` Transformer une figure par rotation et par homothétie | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Sphère, sections et grandeurs | `3E-SPHERE-BOULE` Se repérer sur une sphère, représenter des solides et calculer des volumes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Sphère, sections et grandeurs | `3E-GRANDEURS` Calculer avec des grandeurs composées et vérifier la cohérence des unités | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Statistiques et probabilités | `3E-STATISTIQUES` Représenter des données, calculer effectifs, fréquences et étendue | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Statistiques et probabilités | `3E-PROBABILITES` Calculer des probabilités pour une ou deux épreuves | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Algorithmique et programmation | `3E-PROGRAMMES` Concevoir des programmes avec boucles, conditions, variables et blocs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 3e — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de 4e | `3E-DIAG-NOMBRES` Calculer avec les relatifs, les fractions et les priorités (acquis de 4e) | — | 1 | 3 | — | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 4e | `3E-DIAG-PUISSANCES` Utiliser les puissances de 10 et la notation scientifique (acquis de 4e) | — | — | 2 | — | — | — | 2 | 2 |
| 90. Diagnostic d'entrée, acquis de 4e | `3E-DIAG-LITTERAL` Développer, résoudre une équation, mettre un problème en équation (acquis de 4e) | — | — | 2 | 3 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de 4e | `3E-DIAG-TRIANGLE` Pythagore, Thalès et cosinus dans le triangle (acquis de 4e) | — | — | 3 | 2 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de 4e | `3E-DIAG-GRANDEURS` Volumes, vitesse et probabilités (acquis de 4e) | — | — | 4 | — | — | — | 4 | 4 |

### 2nde — Tronc commun

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Nombres et calculs | `2NDE-FRAC` Calculer avec des fractions | ✓ | 1 | 3 | 1 | 1 | 1 | 7 | 7 |
| 1. Nombres et calculs | `2NDE-PUIS` Calculer avec des puissances | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Nombres et calculs | `2NDE-RAC` Calculer avec des racines carrées | ✓ | 1 | 1 | 3 | 1 | 1 | 7 | 7 |
| 1. Nombres et calculs | `2NDE-ENSEMBLES` Reconnaître les ensembles de nombres | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Nombres et calculs | `2NDE-ENCADR` Encadrer et arrondir un nombre réel | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Calcul littéral | `2NDE-DEV` Développer une expression | ✓ | 1 | 3 | 1 | 1 | 1 | 7 | 7 |
| 2. Calcul littéral | `2NDE-EQ1` Résoudre une équation du premier degré | ✓ | 1 | 2 | 2 | 1 | 1 | 7 | 7 |
| 2. Calcul littéral | `2NDE-EQQUOT` Résoudre une équation quotient | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |
| 3. Intervalles, inégalités et inéquations | `2NDE-INT` Utiliser les intervalles et la valeur absolue | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Intervalles, inégalités et inéquations | `2NDE-INEQ1` Résoudre une inéquation du premier degré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Multiples, diviseurs et nombres premiers | `2NDE-MULT` Utiliser multiples, diviseurs et parité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Multiples, diviseurs et nombres premiers | `2NDE-PREM` Utiliser les nombres premiers et la décomposition | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Proportions et évolutions | `2NDE-PROP` Calculer et utiliser une proportion | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. Proportions et évolutions | `2NDE-EVO` Calculer des évolutions et des taux | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Vecteurs du plan | `2NDE-VEC-COORD` Calculer avec les coordonnées de vecteurs | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Vecteurs du plan | `2NDE-VEC-COL` Étudier la colinéarité de deux vecteurs | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Vecteurs du plan | `2NDE-VEC-GEO` Construire et additionner des vecteurs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Vecteurs du plan | `2NDE-VEC-PB` Résoudre un problème de géométrie avec les vecteurs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Droites et systèmes d'équations | `2NDE-DROITE` Déterminer et utiliser l'équation réduite d'une droite | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 7. Droites et systèmes d'équations | `2NDE-SYST` Résoudre un système de deux équations à deux inconnues | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |
| 7. Droites et systèmes d'équations | `2NDE-DROITE-CART` Utiliser un vecteur directeur et une équation cartésienne | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Généralités sur les fonctions | `2NDE-IMG` Calculer une image et rechercher un antécédent | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 8. Généralités sur les fonctions | `2NDE-COURBE` Exploiter la courbe représentative d'une fonction | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Fonctions de référence | `2NDE-CARRE` Utiliser la fonction carré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Fonctions de référence | `2NDE-INV` Utiliser les fonctions inverse, racine carrée et cube | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Fonctions affines, variations et signe | `2NDE-AFF` Étudier une fonction affine | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 10. Fonctions affines, variations et signe | `2NDE-SIGNE` Étudier le signe d'un produit ou d'un quotient | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 10. Fonctions affines, variations et signe | `2NDE-VARIA` Décrire les variations et les extremums d'une fonction | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Fonctions affines, variations et signe | `2NDE-OPTIM` Modéliser par une fonction et optimiser | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Statistiques descriptives | `2NDE-MOY` Calculer une moyenne et une médiane | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 11. Statistiques descriptives | `2NDE-DISP` Mesurer la dispersion d'une série | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Statistiques descriptives | `2NDE-CROISE` Exploiter un tableau croisé et des fréquences conditionnelles | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 12. Probabilités et échantillonnage | `2NDE-PROBA` Calculer des probabilités | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 12. Probabilités et échantillonnage | `2NDE-ECH` Utiliser la fluctuation d'échantillonnage | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 12. Probabilités et échantillonnage | `2NDE-PCOND` Calculer une probabilité conditionnelle | ✓ | 1 | 1 | 3 | 1 | 1 | 7 | 7 |
| 12. Probabilités et échantillonnage | `2NDE-ARBRE` Construire et exploiter un arbre pondéré | ✓ | 1 | 1 | 3 | 2 | 1 | 8 | 8 |
| 13. Automatismes | `2NDE-AUTO-ECRIT` Changer d'écriture, estimer un ordre de grandeur, contrôler un résultat | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Automatismes | `2NDE-AUTO-UNITES` Convertir des unités | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 13. Automatismes | `2NDE-AUTO-LITT` Calcul littéral élémentaire et formules | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Automatismes | `2NDE-AUTO-COMPAR` Comparer deux nombres ou deux quantités | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Automatismes | `2NDE-AUTO-MESURES` Calculer des périmètres, des aires et des volumes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Automatismes | `2NDE-AUTO-TRIANGLE` Utiliser Pythagore, Thalès et la trigonométrie | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 13. Automatismes | `2NDE-AUTO-GRAPH` Lire et commenter des graphiques usuels | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Automatismes | `2NDE-AUTO-REPERE` Se repérer sur une droite graduée et dans un repère | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 14. Algorithmique et programmation | `2NDE-PY-VAR` Utiliser variables, affectations et instructions conditionnelles | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 14. Algorithmique et programmation | `2NDE-PY-BOUCLE` Programmer une boucle bornée ou non bornée | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 14. Algorithmique et programmation | `2NDE-PY-FONC` Écrire et utiliser des fonctions en Python | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 15. Ensembles, logique et raisonnement | `2NDE-ENS-LOG` Utiliser le vocabulaire des ensembles et les connecteurs logiques | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 15. Ensembles, logique et raisonnement | `2NDE-RAISON` Raisonner avec implications, réciproques et contre-exemples | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 2nde — Voie professionnelle

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Statistique à une variable | `2PRO-STAT-ORGA` Organiser et représenter des données | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Statistique à une variable | `2PRO-STAT-POS` Calculer et interpréter des indicateurs de position | ✓ | 1 | 2 | 2 | 1 | 1 | 7 | 7 |
| 1. Statistique à une variable | `2PRO-STAT-DISP` Mesurer la dispersion et utiliser un diagramme en boîte | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |

### 2nde — Excellence et olympiades

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Arithmétique approfondie | `2NDE-EX-ARITHM` Raisonner sur les entiers (diviseurs, restes, divisibilité) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Arithmétique approfondie | `2NDE-EX-ARITH-PB` Problème guidé : les nombres parfaits | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Ordre et inégalités | `2NDE-EX-INEG` Comparer des nombres et démontrer des inégalités | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Ordre et inégalités | `2NDE-EX-ORDRE-PB` Problème guidé : l'inégalité des moyennes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, algèbre et combinatoire | `2NDE-EX-OLYMPIADE` Résoudre des problèmes de type olympiade (sommes, comptages, identités) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, algèbre et combinatoire | `2NDE-EX-OLYMP-PB` Problème guidé : poignées de main et diagonales | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Géométrie et vecteurs approfondis | `2NDE-EX-GEOMETRIE` Calculer longueurs, angles et aires dans des configurations riches | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Géométrie et vecteurs approfondis | `2NDE-EX-GEO-PB` Problème guidé : le centre de gravité d'un triangle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Fonctions et équations | `2NDE-EX-FONCTIONS` Raisonner sur les fonctions (composition, extremum, équations fonctionnelles) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Fonctions et équations | `2NDE-EX-FONC-PB` Problème guidé : l'enclos le long d'un mur | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Dénombrement et principe des tiroirs | `2NDE-EX-DENOMBR` Compter méthodiquement (arrangements, complémentaire, tiroirs) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Dénombrement et principe des tiroirs | `2NDE-EX-DENOMB-PB` Problème guidé : chemins et triangle de Pascal | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 2nde — Mise à niveau

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Bases du collège, calcul numérique | `2NDE-MAN-CALCUL` Calculer avec fractions, priorités et puissances | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Bases du collège, calcul littéral et équations | `2NDE-MAN-EQUATIONS` Développer, réduire et résoudre une équation du premier degré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Bases du collège, proportionnalité et géométrie | `2NDE-MAN-PROPORTION` Utiliser pourcentages, proportionnalité, Pythagore et Thalès | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 2nde — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de 3e | `2NDE-DIAG-NOMBRES` Fractions et racines carrées (acquis du collège) | — | 1 | 1 | — | — | — | 2 | 2 |
| 90. Diagnostic d'entrée, acquis de 3e | `2NDE-DIAG-LITTERAL` Développer, factoriser, résoudre une équation produit (acquis de 3e) | — | — | 4 | 2 | — | — | 6 | 6 |
| 90. Diagnostic d'entrée, acquis de 3e | `2NDE-DIAG-FONCTIONS` Image, antécédent, fonctions affines (acquis de 3e) | — | 1 | 2 | 2 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de 3e | `2NDE-DIAG-GEOMETRIE` Thalès et trigonométrie (acquis de 3e) | — | — | 2 | 1 | — | — | 3 | 3 |
| 90. Diagnostic d'entrée, acquis de 3e | `2NDE-DIAG-DONNEES` Statistiques, probabilités et pourcentages (acquis de 3e) | — | 1 | 2 | 1 | — | — | 4 | 4 |

### 1re — Spécialité

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Second degré | `1RE-SD-FACTO-SIGNE` Exploiter la forme factorisée (racines, signe, somme et produit) | ✓ | 2 | 3 | 2 | 2 | 1 | 10 | 10 |
| 1. Second degré | `1RE-SD-CANON` Déterminer et utiliser la forme canonique | ✓ | 2 | 2 | 3 | 2 | 1 | 10 | 10 |
| 1. Second degré | `1RE-DISC` Résoudre une équation du second degré avec le discriminant | ✓ | 1 | 3 | 3 | 2 | 1 | 10 | 10 |
| 1. Second degré | `1RE-SD-FACTO` Factoriser en diversifiant les stratégies | ✓ | 2 | 2 | 3 | 1 | 1 | 9 | 9 |
| 1. Second degré | `1RE-SD-PROBLEME` Choisir une forme adaptée pour résoudre un problème | ✓ | 1 | 2 | 2 | 2 | 1 | 8 | 8 |
| 2. Suites numériques | `1RE-SUI-TERME` Calculer les termes d'une suite | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Suites numériques | `1RE-SUI-MOD` Modéliser une situation par une suite | ✓ | 1 | 2 | 2 | 1 | 1 | 7 | 7 |
| 2. Suites numériques | `1RE-SUI-VAR` Étudier le sens de variation d'une suite | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Suites numériques | `1RE-SUI-SOMME` Calculer une somme de termes et conjecturer une limite | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Dérivation | `1RE-DER-NB` Utiliser le nombre dérivé et la tangente | ✓ | 1 | 1 | 2 | 2 | 1 | 7 | 7 |
| 3. Dérivation | `1RE-DER-CALC` Calculer une fonction dérivée | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 3. Dérivation | `1RE-DER-LOCAL` Utiliser l'approximation affine et étudier la dérivabilité en un point | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Applications de la dérivation | `1RE-VAR` Déduire les variations du signe de la dérivée | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Applications de la dérivation | `1RE-EXTR` Déterminer un extremum et résoudre un problème d'optimisation | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 4. Applications de la dérivation | `1RE-PARITE` Reconnaître une fonction paire ou impaire | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Fonction exponentielle | `1RE-EXP-ALG` Utiliser les propriétés algébriques de l'exponentielle | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. Fonction exponentielle | `1RE-EXP-ETU` Dériver et étudier des fonctions avec l'exponentielle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Trigonométrie | `1RE-RAD` Utiliser le radian et la mesure principale | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Trigonométrie | `1RE-COSSIN` Calculer avec cosinus et sinus | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Produit scalaire | `1RE-PS-CALC` Calculer un produit scalaire | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 7. Produit scalaire | `1RE-PS-APP` Utiliser le produit scalaire (orthogonalité, angles, longueurs) | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 7. Produit scalaire | `1RE-PS-MAMB` Utiliser le produit scalaire MA·MB | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Géométrie repérée | `1RE-NORMAL` Utiliser un vecteur normal à une droite | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Géométrie repérée | `1RE-CERCLE` Déterminer et utiliser l'équation d'un cercle | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 8. Géométrie repérée | `1RE-PROJ` Déterminer un projeté orthogonal et étudier une configuration en repère | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Probabilités conditionnelles et indépendance | `1RE-COND` Calculer une probabilité conditionnelle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Probabilités conditionnelles et indépendance | `1RE-TOTALES` Utiliser un arbre et la formule des probabilités totales | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 9. Probabilités conditionnelles et indépendance | `1RE-BERNOULLI` Répéter des épreuves de Bernoulli indépendantes (n ⩽ 4) | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 10. Variables aléatoires réelles | `1RE-LOI` Déterminer une loi de probabilité et une espérance | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 10. Variables aléatoires réelles | `1RE-VARIANCE` Calculer une variance et un écart type | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Variables aléatoires réelles | `1RE-VA-LIN` Utiliser la linéarité de l'espérance | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Automatismes | `1RE-AUTO-EVO` Calculer avec des taux d'évolution | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 11. Automatismes | `1RE-AUTO-CALC` Automatismes de calcul algébrique et de signe | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Automatismes | `1RE-AUTO-GRAPH` Lectures graphiques de fonctions et de droites | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Automatismes | `1RE-AUTO-STAT` Lire des représentations de données et calculer des indicateurs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 12. Algorithmique et listes | `1RE-LISTE` Générer, manipuler et parcourir une liste en Python | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Enseignement scientifique

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Information chiffrée, évolutions et pourcentages | `1RE-ES-EVO-TAUX` Calculer et enchainer des évolutions en pourcentage | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Statistiques à deux caractères | `1RE-ES-CROISE` Exploiter un tableau croisé d'effectifs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Statistiques à deux caractères | `1RE-ES-AJUST` Calculer un point moyen et utiliser un ajustement affine | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Probabilités conditionnelles et indépendance | `1RE-ES-PCOND` Calculer des probabilités conditionnelles avec un arbre ou un tableau | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Probabilités conditionnelles et indépendance | `1RE-ES-INDEP` Utiliser l'indépendance et la répétition d'épreuves | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Variation linéaire, suites arithmétiques | `1RE-ES-ARITH` Modéliser une croissance linéaire par une suite arithmétique ou une fonction affine | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Modélisation quadratique | `1RE-ES-PARAB` Exploiter une fonction polynôme de degré 2 (parabole, sommet, racines, signe) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Variation exponentielle, suites géométriques | `1RE-ES-GEOM` Modéliser une évolution à taux constant par une suite géométrique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Variation exponentielle, suites géométriques | `1RE-ES-PUISS` Utiliser les fonctions exponentielles et le taux moyen | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Voie technologique

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Automatismes, évolutions et calcul algébrique | `1RE-TEC-EVO` Calculer des évolutions en pourcentage | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Automatismes, évolutions et calcul algébrique | `1RE-TEC-CALC` Résoudre une équation produit nul et étudier un signe | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Automatismes, évolutions et calcul algébrique | `1RE-TEC-GRAPH` Lectures graphiques de fonctions et de droites | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Automatismes, évolutions et calcul algébrique | `1RE-TEC-STAT` Lire des représentations de données et calculer des indicateurs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Suites arithmétiques et géométriques | `1RE-TEC-SUITES` Modéliser par une suite arithmétique ou géométrique | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Suites arithmétiques et géométriques | `1RE-TEC-SUI-GRAPH` Représenter une suite et automatiser ses calculs | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Fonctions polynômes du second degré | `1RE-TEC-POLY2` Exploiter la forme factorisée d'un polynôme du second degré | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Fonctions polynômes du second degré | `1RE-TEC-FONC` Modéliser par une fonction et utiliser le taux de variation | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 4. Dérivation | `1RE-TEC-DERIV` Calculer un nombre dérivé, une dérivée et une tangente | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Dérivation | `1RE-TEC-VARIA` Étudier les variations et les extremums avec la dérivée | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Séries statistiques à deux variables | `1RE-TEC-STAT2` Utiliser un nuage de points et un ajustement affine | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 6. Probabilités conditionnelles et indépendance | `1RE-TEC-PCOND` Calculer des probabilités conditionnelles (tableau, arbre) | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Probabilités conditionnelles et indépendance | `1RE-TEC-BERN` Répéter des épreuves de Bernoulli indépendantes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Variables aléatoires | `1RE-TEC-VA` Déterminer une loi de probabilité et une espérance | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 7. Variables aléatoires | `1RE-TEC-SIMUL` Simuler des échantillons d'une loi de Bernoulli | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Logique, algorithmique et programmation | `1RE-TEC-LOGIQUE` Raisonner avec les connecteurs, les conditions et les contre-exemples | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Logique, algorithmique et programmation | `1RE-TEC-ALGO` Programmer avec compteurs, accumulateurs, fonctions et listes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Excellence et olympiades

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Logique et raisonnements | `1RE-EX-LOGIQUE` Utiliser quantificateurs, négation, contraposée et récurrence | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Logique et raisonnements | `1RE-EX-LOG-PB` Problème guidé : la somme des cubes par récurrence | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Ensembles et applications | `1RE-EX-APPLI` Étudier injectivité, surjectivité, bijection et compter des applications | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Ensembles et applications | `1RE-EX-ENS-PB` Problème guidé : composer et inverser des fonctions | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, géométrie et trigonométrie | `1RE-EX-OLYMPIADE` Résoudre des problèmes de type olympiade en géométrie et trigonométrie | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, géométrie et trigonométrie | `1RE-EX-OLYMP-PB` Problème guidé : tout savoir sur le triangle 13-14-15 | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Suites et récurrences avancées | `1RE-EX-SUITES` Calculer avec des suites récurrentes et des sommes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Suites et récurrences avancées | `1RE-EX-SUI-PB` Problème guidé : un placement avec versements réguliers | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Second degré avec paramètre, somme et produit des racines | `1RE-EX-POLYNOMES` Utiliser somme et produit des racines sans les calculer | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Second degré avec paramètre, somme et produit des racines | `1RE-EX-POLY-PB` Problème guidé : une équation avec paramètre | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Probabilités approfondies | `1RE-EX-PROBAS` Résoudre des problèmes de probabilités classiques | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Probabilités approfondies | `1RE-EX-PROBA-PB` Problème guidé : faux positifs et second test | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Mise à niveau

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Bases de seconde, calcul algébrique | `1RE-MAN-ALGEBRE` Résoudre équations, inéquations et systèmes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Bases de seconde, fonctions et droites | `1RE-MAN-FONCTIONS` Calculer des images, des équations de droites et étudier un signe | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Bases de seconde, vecteurs, statistiques et probabilités | `1RE-MAN-VECPROBA` Calculer avec des coordonnées, une moyenne et une probabilité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Préparation aux examens

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Épreuve anticipée, partie automatismes (QCM) | `1RE-EXA-AUTO-CALC` Automatismes de calcul (QCM sans calculatrice) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Épreuve anticipée, partie automatismes (QCM) | `1RE-EXA-AUTO-FONC` Automatismes sur fonctions, statistiques et probabilités (QCM) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Sujet blanc n° 1 (second degré et suites) | `1RE-EXA-B1-EX1` Exercice 1 : bénéfice et second degré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Sujet blanc n° 1 (second degré et suites) | `1RE-EXA-B1-EX2` Exercice 2 : évolution d'une population | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Sujet blanc n° 2 (dérivation et probabilités) | `1RE-EXA-B2-EX1` Exercice 1 : étude d'une fonction polynôme | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Sujet blanc n° 2 (dérivation et probabilités) | `1RE-EXA-B2-EX2` Exercice 2 : un jeu de hasard | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### 1re — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, acquis de 2nde | `1RE-DIAG-ALGEBRE` Calcul algébrique, équations et inéquations (acquis de 2nde) | — | 1 | 5 | 1 | — | — | 7 | 7 |
| 90. Diagnostic d'entrée, acquis de 2nde | `1RE-DIAG-FONCTIONS` Droites, fonctions de référence et lecture graphique (acquis de 2nde) | — | 1 | 1 | 2 | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, acquis de 2nde | `1RE-DIAG-GEOMETRIE` Vecteurs et coordonnées (acquis de 2nde) | — | — | 1 | — | — | — | 1 | 1 |
| 90. Diagnostic d'entrée, acquis de 2nde | `1RE-DIAG-DONNEES` Évolutions, statistiques et probabilités (acquis de 2nde) | — | 1 | 3 | 1 | — | — | 5 | 5 |
| 90. Diagnostic d'entrée, acquis de 2nde | `1RE-DIAG-RAISONNEMENT` Algorithmique et raisonnement (acquis de 2nde) | — | — | 1 | 2 | — | — | 3 | 3 |

### Tle — Spécialité

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Combinatoire et dénombrement | `TLE-COMB-DEN` Dénombrer avec les listes et les combinaisons | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Vecteurs, droites et plans de l'espace | `TLE-ESP-COORD` Calculer avec des coordonnées dans l'espace | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Vecteurs, droites et plans de l'espace | `TLE-ESP-COPLAN` Décomposer un vecteur et étudier la coplanarité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Orthogonalité et distances dans l'espace | `TLE-PS-ESP` Utiliser le produit scalaire dans l'espace | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Orthogonalité et distances dans l'espace | `TLE-PLAN-NORMAL` Utiliser un vecteur normal à un plan | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Représentations paramétriques et équations cartésiennes | `TLE-DROITE-ESP` Utiliser une représentation paramétrique de droite | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Représentations paramétriques et équations cartésiennes | `TLE-INTERSECTION` Déterminer l'intersection d'une droite et d'un plan | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Suites | `TLE-SUI-REC` Raisonner par récurrence | ✓ | 1 | 1 | 1 | 1 | 2 | 6 | 6 |
| 5. Suites | `TLE-SUI-LIM` Définir la limite d'une suite | ✓ | 1 | 2 | 2 | 1 | 1 | 7 | 7 |
| 5. Suites | `TLE-SUI-OPE` Déterminer la limite d'une suite par opérations | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |
| 5. Suites | `TLE-SUI-COMP` Déterminer la limite d'une suite par comparaison | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 6. Limites de fonctions | `TLE-LIMF-OP` Calculer une limite par opérations et lever une indétermination | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Limites de fonctions | `TLE-LIMF-ASYMP` Interpréter des limites (asymptotes, croissances comparées) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Compléments sur la dérivation et convexité | `TLE-COMPOSEE` Dériver une fonction composée | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Compléments sur la dérivation et convexité | `TLE-CONVEX` Étudier la convexité d'une fonction | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Continuité des fonctions | `TLE-TVI` Appliquer le théorème des valeurs intermédiaires | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Continuité des fonctions | `TLE-POINT-FIXE` Déterminer la limite d'une suite récurrente | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Fonction logarithme népérien | `TLE-LN-DEF` Définir la fonction logarithme népérien | ✓ | 2 | 2 | 1 | 1 | 1 | 7 | 7 |
| 9. Fonction logarithme népérien | `TLE-LN-ETU` Étudier la fonction logarithme népérien | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 9. Fonction logarithme népérien | `TLE-LN-APP` Approfondir l'étude de la fonction logarithme népérien | ✓ | 1 | 1 | 2 | 3 | 1 | 8 | 8 |
| 10. Fonctions trigonométriques | `TLE-TRIG-ETU` Dériver et étudier les fonctions sinus et cosinus | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Fonctions trigonométriques | `TLE-TRIG-EQ` Résoudre des équations trigonométriques | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Primitives et équations différentielles | `TLE-PRIM` Déterminer une primitive | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 11. Primitives et équations différentielles | `TLE-EQDIFF` Résoudre une équation différentielle y' = ay + b | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 12. Calcul intégral | `TLE-INT-CALC` Calculer une intégrale à l'aide d'une primitive | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 12. Calcul intégral | `TLE-INT-APP` Utiliser l'intégrale (aires, valeur moyenne, intégration par parties) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Succession d'épreuves indépendantes, loi binomiale | `TLE-BINOM-LOI` Calculer des probabilités avec la loi binomiale | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 13. Succession d'épreuves indépendantes, loi binomiale | `TLE-BINOM-ESP` Utiliser espérance et variance d'une loi binomiale | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 14. Sommes de variables aléatoires | `TLE-SOMME-LIN` Calculer espérance et variance d'une somme | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 14. Sommes de variables aléatoires | `TLE-ECHANTILLON` Étudier la somme et la moyenne d'un échantillon | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 15. Concentration et loi des grands nombres | `TLE-BIENAYME` Appliquer l'inégalité de Bienaymé-Tchebychev | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 15. Concentration et loi des grands nombres | `TLE-CONCENTRATION` Utiliser l'inégalité de concentration et la loi des grands nombres | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### Tle — Maths complémentaires

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Suites numériques et modèles discrets | `TLE-MC-SUI-LIM` Calculer la limite d'une suite géométrique et d'une somme géométrique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Suites numériques et modèles discrets | `TLE-MC-SUI-AG` Étudier une suite arithmético-géométrique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Limites, continuité et valeurs intermédiaires | `TLE-MC-LIM` Calculer des limites et interpréter les asymptotes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Limites, continuité et valeurs intermédiaires | `TLE-MC-TVI` Utiliser le théorème des valeurs intermédiaires | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Logarithme népérien et dérivation | `TLE-MC-LN-ALG` Utiliser le logarithme pour résoudre équations et seuils | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Logarithme népérien et dérivation | `TLE-MC-DERIV` Dériver des fonctions composées simples | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Primitives et équations différentielles | `TLE-MC-PRIMITIVE` Déterminer une primitive | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Primitives et équations différentielles | `TLE-MC-EQDIFF` Résoudre les équations différentielles y' = ay et y' = ay + b | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Fonctions convexes | `TLE-MC-CONVEX` Étudier la convexité d'une fonction | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Intégration | `TLE-MC-INT` Calculer une intégrale à l'aide d'une primitive | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Intégration | `TLE-MC-INT-APP` Calculer aires et valeurs moyennes, approcher une intégrale | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Lois discrètes | `TLE-MC-BINOM` Utiliser la loi de Bernoulli et la loi binomiale | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Lois discrètes | `TLE-MC-GEOM` Utiliser la loi uniforme et la loi géométrique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Lois à densité | `TLE-MC-UNIF` Utiliser une densité et la loi uniforme | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Lois à densité | `TLE-MC-EXPO` Utiliser la loi exponentielle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Statistique à deux variables quantitatives | `TLE-MC-STAT2` Ajuster un nuage de points (point moyen, moindres carrés, changement de variable) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### Tle — Maths expertes

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Nombres complexes, forme algébrique et équations | `TLE-ME-CPLX-ALG` Calculer avec la forme algébrique et le conjugué | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 1. Nombres complexes, forme algébrique et équations | `TLE-ME-CPLX-EQ` Résoudre une équation polynomiale dans les complexes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Nombres complexes, forme algébrique et équations | `TLE-ME-BINOME` Utiliser la formule du binôme dans ℂ | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Nombres complexes, forme algébrique et équations | `TLE-ME-POLY` Factoriser un polynôme dont une racine est connue | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Module, argument et géométrie | `TLE-ME-CPLX-TRIG` Utiliser module, argument et forme exponentielle | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 2. Module, argument et géométrie | `TLE-ME-CPLX-GEOM` Résoudre des problèmes de géométrie avec les complexes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Module, argument et géométrie | `TLE-ME-EULER` Utiliser les formules d'addition, d'Euler et de Moivre | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Racines n-ièmes de l'unité et équations polynomiales | `TLE-ME-RACINES` Utiliser les racines n-ièmes de l'unité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Divisibilité et congruences | `TLE-ME-DIV` Utiliser la divisibilité et la division euclidienne | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 4. Divisibilité et congruences | `TLE-ME-CONG` Calculer avec les congruences | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 5. PGCD, théorèmes de Bézout et de Gauss | `TLE-ME-PGCD-CALC` Calculer un PGCD avec l'algorithme d'Euclide | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. PGCD, théorèmes de Bézout et de Gauss | `TLE-ME-BEZOUT` Utiliser les théorèmes de Bézout et de Gauss | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. PGCD, théorèmes de Bézout et de Gauss | `TLE-ME-DIOPH` Résoudre une congruence ax ≡ b [n] et une équation diophantienne | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Nombres premiers et petit théorème de Fermat | `TLE-ME-PREM` Utiliser les nombres premiers et le petit théorème de Fermat | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Nombres premiers et petit théorème de Fermat | `TLE-ME-PREM-ALGO` Démontrer l'infinité des nombres premiers et programmer les algorithmes d'arithmétique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Matrices et systèmes linéaires | `TLE-ME-MAT-CALC` Calculer avec des matrices | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 7. Matrices et systèmes linéaires | `TLE-ME-MAT-SYS` Résoudre un système linéaire avec une matrice inverse | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Matrices et systèmes linéaires | `TLE-ME-MAT-SUITE` Étudier une suite de matrices Uₙ₊₁ = AUₙ + C | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Graphes et chaînes de Markov | `TLE-ME-GRAPHE` Utiliser le vocabulaire des graphes et la matrice d'adjacence | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Graphes et chaînes de Markov | `TLE-ME-MARKOV` Étudier une chaîne de Markov à deux états | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |

### Tle — Voie technologique

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Automatismes, proportions et indices | `TLE-TEC-INDICE` Calculer des proportions de proportions et des indices base 100 | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 1. Automatismes, proportions et indices | `TLE-TEC-AUTO-EVO` Automatismes sur les évolutions en pourcentage | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Suites arithmétiques et géométriques, sommes | `TLE-TEC-ARITH` Calculer termes et sommes d'une suite arithmétique | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 2. Suites arithmétiques et géométriques, sommes | `TLE-TEC-GEOM` Calculer termes et sommes d'une suite géométrique | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 3. Fonctions exponentielles x ↦ a^x | `TLE-TEC-EXPA` Utiliser les fonctions exponentielles de base a | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Fonction logarithme décimal | `TLE-TEC-LOG` Utiliser le logarithme décimal | ✓ | 1 | 2 | 1 | 1 | 1 | 6 | 6 |
| 5. Fonction inverse | `TLE-TEC-INV` Étudier la fonction inverse et l'utiliser dans un problème | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Séries statistiques à deux variables, changement de variable | `TLE-TEC-AJUST` Utiliser un ajustement après changement de variable | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Probabilités conditionnelles et probabilités totales | `TLE-TEC-PROBA` Utiliser la formule des probabilités totales | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 8. Variables aléatoires et loi binomiale | `TLE-TEC-BINOM` Utiliser la loi binomiale et son espérance | ✓ | 1 | 1 | 2 | 1 | 1 | 6 | 6 |
| 9. Automatismes | `TLE-TEC-AUTO-NOMB` Automatismes de calcul numérique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Automatismes | `TLE-TEC-AUTO-ALG` Automatismes de calcul algébrique | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Automatismes | `TLE-TEC-AUTO-FONC` Lectures graphiques et représentations de données | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 9. Automatismes | `TLE-TEC-AUTO-DROITE` Droites, dérivées et tangentes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Logique, algorithmique et programmation | `TLE-TEC-LOGIQUE` Raisonner avec les connecteurs, les conditions et les contre-exemples | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 10. Logique, algorithmique et programmation | `TLE-TEC-ALGO` Programmer des calculs de sommes, de seuils et de lois binomiales | ✓ | 1 | 1 | 1 | 2 | 1 | 6 | 6 |

### Tle — Excellence et olympiades

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Suites et limites approfondies | `TLE-EX-SUITES` Calculer des limites de suites délicates | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Suites et limites approfondies | `TLE-EX-SUI-PB` Problème guidé : convergence et vitesse de la suite racine de (2 + u) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Logarithme, exponentielle et QCM de concours | `TLE-EX-FONC` Résoudre rapidement des questions de concours sur ln et exp | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Logarithme, exponentielle et QCM de concours | `TLE-EX-CONC-PB` Problème guidé : comparer e puissance pi et pi puissance e | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, arithmétique et dénombrement | `TLE-EX-OLYMPIADE` Résoudre des problèmes de type olympiade en arithmétique et dénombrement | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Olympiades, arithmétique et dénombrement | `TLE-EX-OLYMP-PB` Problème guidé : le critère de divisibilité par 11 | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Vers la prépa MPSI, sommes et raisonnement | `TLE-EX-MPSI-SOMMES` Manipuler sommes, factorielles et parties entières | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 4. Vers la prépa MPSI, sommes et raisonnement | `TLE-EX-MPSI-PB` Problème guidé : calculer la somme des k fois 2 puissance k | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Vers la prépa PCSI, calcul et nombres complexes | `TLE-EX-PCSI-CALCUL` Maîtriser le calcul intégral et la forme exponentielle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 5. Vers la prépa PCSI, calcul et nombres complexes | `TLE-EX-PCSI-PB` Problème guidé : les intégrales de Wallis | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Vers la prépa commerciale (ECG), probabilités et suites | `TLE-EX-ECG-PROBA` Modéliser par des probabilités et des suites récurrentes | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 6. Vers la prépa commerciale (ECG), probabilités et suites | `TLE-EX-ECG-PB` Problème guidé : la fidélité des clients (chaîne à deux états) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Intégrales et suites d'intégrales | `TLE-EX-INTEGRALES` Calculer des intégrales astucieuses | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 7. Intégrales et suites d'intégrales | `TLE-EX-INT-PB` Problème guidé : la suite d'intégrales J(n) | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Géométrie dans l'espace approfondie | `TLE-EX-ESPACE` Calculer longueurs, angles, aires et volumes dans l'espace | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 8. Géométrie dans l'espace approfondie | `TLE-EX-ESP-PB` Problème guidé : projeté orthogonal et distance à un plan | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### Tle — Mise à niveau

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Bases de première, second degré | `TLE-MAN-SECOND` Résoudre et étudier un trinôme du second degré | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Bases de première, dérivation et variations | `TLE-MAN-DERIVATION` Dériver, écrire une tangente et trouver un extremum | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Bases de première, suites et exponentielle | `TLE-MAN-SUITES-EXP` Calculer avec les suites usuelles et la fonction exponentielle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### Tle — Préparation aux examens

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1. Bac blanc n° 1 (exponentielle et probabilités) | `TLE-EXA-B1-EX1` Exercice 1 : étude d'une fonction exponentielle | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 1. Bac blanc n° 1 (exponentielle et probabilités) | `TLE-EXA-B1-EX2` Exercice 2 : contrôle qualité | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Bac blanc n° 2 (suites et géométrie dans l'espace) | `TLE-EXA-B2-EX1` Exercice 1 : une suite définie par récurrence | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 2. Bac blanc n° 2 (suites et géométrie dans l'espace) | `TLE-EXA-B2-EX2` Exercice 2 : tétraèdre et plan dans l'espace | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Sujet type annales (logarithme et équation différentielle) | `TLE-EXA-AN-EX1` Exercice 1 : une fonction avec le logarithme | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |
| 3. Sujet type annales (logarithme et équation différentielle) | `TLE-EXA-AN-EX2` Exercice 2 : une équation différentielle en contexte | ✓ | 1 | 1 | 1 | 1 | 1 | 5 | 5 |

### Tle — Diagnostic des acquis antérieurs

| Chapitre | Compétence | Cours | 1 | 2 | 3 | 4 | 5 | Total | À valider |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 90. Diagnostic d'entrée, socle commun | `TLE-DIAG-SOCLE-CALCUL` Fractions, développement et équations (bases du lycée) | — | — | 4 | — | — | — | 4 | 4 |
| 90. Diagnostic d'entrée, socle commun | `TLE-DIAG-SOCLE-DONNEES` Pourcentages et probabilités (bases du lycée) | — | 1 | — | 1 | — | — | 2 | 2 |
| 91. Diagnostic d'entrée, acquis de spécialité de 1re | `TLE-DIAG-SPE-ANALYSE` Second degré, dérivation et variations (acquis de 1re spécialité) | — | — | 2 | 1 | — | — | 3 | 3 |
| 91. Diagnostic d'entrée, acquis de spécialité de 1re | `TLE-DIAG-SPE-SUITES-PROBAS` Suites et probabilités conditionnelles (acquis de 1re spécialité) | — | — | 2 | 1 | — | — | 3 | 3 |
| 92. Diagnostic d'entrée, acquis de 1re technologique | `TLE-DIAG-TECH-FONCTIONS` Calcul et fonctions (acquis de 1re technologique) | — | 1 | 1 | — | — | — | 2 | 2 |
| 92. Diagnostic d'entrée, acquis de 1re technologique | `TLE-DIAG-TECH-DONNEES` Statistiques, probabilités, suites et algorithmique (acquis de 1re technologique) | — | 2 | 2 | — | — | — | 4 | 4 |

## Trous à combler

Aucun.

## Registre des sources

| Source | Licence de la source | Adaptation | Questions |
|---|---|---|:-:|
| PKP Math | — | originale | 1884 |
| math.ma | non clarifiée | inspiree | 33 |
| MathALÉA | CC BY-SA 4.0 | inspiree | 5 |
| STACK | à vérifier | inspiree | 3 |
| APMEP (annales du bac) | non clarifiée | inspiree | 2 |

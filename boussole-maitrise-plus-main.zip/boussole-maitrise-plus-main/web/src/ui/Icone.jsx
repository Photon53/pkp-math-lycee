// Icônes au trait (24 × 24, trait 1,5 px), intégrées au code : aucun appel à un tiers.
const TRACES = {
  accueil: "M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  classes: "M16 19v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 17.5V19M10 10.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6M20 19v-1.5a3.5 3.5 0 0 0-2.5-3.35M15 4.6a3 3 0 0 1 0 5.8",
  cours: "M4 5.5A1.5 1.5 0 0 1 5.5 4H11v15H5.5A1.5 1.5 0 0 0 4 20.5zM20 5.5A1.5 1.5 0 0 0 18.5 4H13v15h5.5a1.5 1.5 0 0 1 1.5 1.5zM4 20.5V5.5M20 20.5V5.5",
  exercices: "M9 11l2 2 4-4M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1",
  ressources: "M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1",
  lien: "M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5",
  pdf: "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M9 13h6M9 17h4",
  tableau: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  professeurs: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1",
  journal: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  sortie: "M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 16l-4-4 4-4M6 12h10",
  bouclier: "M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z",
  menu: "M4 6h16M4 12h16M4 18h16",
  plus: "M12 5v14M5 12h14",
  telecharger: "M12 4v11M7 10l5 5 5-5M5 20h14",
  recherche: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14M20 20l-4-4",
  ecran: "M3 5h18v11H3zM8 20h8M12 16v4",
  imprimer: "M7 9V3h10v6M7 17H5a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2M7 14h10v7H7z",
  fermer: "M6 6l12 12M18 6 6 18",
  ok: "M5 12.5l4.5 4.5L19 7.5",
  ko: "M12 8v5M12 16.5h.01M12 3l9.5 17h-19z",
  oeil: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
  oeilBarre: "M3 3l18 18M10.6 5.1A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.7 8.4 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.5 4.8-1.3M9.9 9.9a3 3 0 0 0 4.2 4.2",
  crayon: "M4 20h4L19 9l-4-4L4 16zM14 6l4 4",
  poubelle: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3",
  poignee: "M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01",
  eleve: "M2 9l10-5 10 5-10 5zM6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5",
  cle: "M15 7a4 4 0 1 1-3.5 6L4 20.5V17h3v-3h3l1.5-1.5",
};

export default function Icone({ nom, taille = 20, titre, className }) {
  return (
    <svg
      width={taille}
      height={taille}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      role={titre ? "img" : undefined}
      aria-label={titre}
      aria-hidden={titre ? undefined : true}
    >
      <path d={TRACES[nom]} />
    </svg>
  );
}

/** Monogramme Boussole : un carré bleu encre et une aiguille de boussole (nord orange). */
export function Monogramme({ taille = 32 }) {
  return (
    <svg className="monogramme" width={taille} height={taille} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="#1f3a68" />
      <circle cx="16" cy="16" r="10.5" fill="none" stroke="#ffffff" strokeWidth="2" />
      <path d="M16 6.5 19.2 16h-6.4z" fill="#e07a1f" />
      <path d="M16 25.5 12.8 16h6.4z" fill="#ffffff" />
      <circle cx="16" cy="16" r="1.6" fill="#1f3a68" />
    </svg>
  );
}

/**
 * Rose des vents de l'accueil Boussole (#149) : pur décor, masquée aux lecteurs d'écran et sur téléphone.
 * Aiguille nord orange (couleur du monogramme), aiguille sud claire, graduations discrètes.
 */
export function RoseDesVents() {
  return (
    <svg className="rose-des-vents" viewBox="0 0 200 200" aria-hidden="true" focusable="false">
      <circle cx="100" cy="100" r="96" fill="none" stroke="#2a3b5c" />
      <circle cx="100" cy="100" r="80" fill="rgb(255 255 255 / 3%)" stroke="#3a4d74" />
      <circle cx="100" cy="100" r="56" fill="none" stroke="#22345a" strokeDasharray="2 4" />
      <path d="M100 4v10M100 186v10M4 100h10M186 100h10" stroke="#5b6f96" />
      <path d="M32 32l6 6M162 162l6 6M168 32l-6 6M38 162l-6 6" stroke="#3a4d74" />
      <g fill="#a9b6cf" fontSize="9" fontWeight="600" textAnchor="middle">
        <text x="100" y="26">N</text>
        <text x="100" y="182">S</text>
        <text x="178" y="103">E</text>
        <text x="22" y="103">O</text>
      </g>
      <path d="M100 30 112 100 100 108 88 100Z" fill="#f2a65a" />
      <path d="M100 170 88 100 100 92 112 100Z" fill="#dce4f3" />
      <circle cx="100" cy="100" r="5" fill="#0b1426" stroke="#f2a65a" strokeWidth="2" />
    </svg>
  );
}

/** `nom`, `marque` et `monogramme` : identité de la variante (Boussole Maîtrise+ par défaut, PKP Éducation). */
export function Logo({ vers = "/", nom = "Boussole", marque = "Maîtrise+", monogramme = true }) {
  return (
    <a className="logo" href={vers}>
      {monogramme && <Monogramme />}
      <span>
        {nom} <em>{marque}</em>
      </span>
    </a>
  );
}

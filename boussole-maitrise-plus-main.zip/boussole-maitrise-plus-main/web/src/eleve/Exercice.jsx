import { useEffect, useRef, useState } from "react";
import { api } from "../api.js";
import { BarreMaitrise, Difficulte, Erreur, LIBELLES_TYPE, solutionLisible } from "../composants.jsx";
import { Maths } from "../maths.jsx";
import { AideExercice } from "./Comprehension.jsx";
import { Correction } from "../ui/Pedagogie.jsx";
import { ecrire, lire } from "../stockage.js";
import { CONSEILS } from "../methodeEtapes.js";
import ConseilsTravail from "./ConseilsTravail.jsx";

export const CLE_SEANCE = "pkp.seance";
export const CLE_BILAN = "pkp.bilan";
export const CLE_CIBLE = "pkp.cible";
const BILAN_VIDE = { reponses: 0, reussies: 0 };

const AIDE = {
  numerique: "Écris 1/2, 0,5 ou -3, ou une valeur exacte comme ln(5), e^2, sqrt(2).",
  expression: "Écris x^2 ou x², 2x pour 2×x, sqrt(…), ln(x), e^x. Parenthèses conseillées : ln(2x).",
  qcm: "Écris la lettre de la bonne réponse.",
  texte: "Écris ta réponse en toutes lettres : les accents comptent, pas les majuscules.",
};

// « … ? A) positif  B) négatif » → intitulé + options cliquables.
export function decouperQcm(enonce) {
  const options = [...enonce.matchAll(/\b([A-F])\)\s*(.*?)(?=\s+[A-F]\)|$)/g)];
  if (options.length < 2) return { intitule: enonce, options: null };
  return {
    intitule: enonce.slice(0, options[0].index).trim(),
    options: options.map((m) => ({ lettre: m[1], texte: m[2].trim() })),
  };
}

/**
 * Déroulé d'une séance : accueil → question → résultat → question… → bilan.
 * La séance en cours est mémorisée : au retour, « Reprendre ma séance » rouvre la même séance et la même
 * question, sans en créer une nouvelle (#148).
 */
export default function Exercice({ jeton, onExpire, onVoirCours, cible }) {
  const [seanceId, setSeanceId] = useState(() => lire(CLE_SEANCE));
  const [etape, setEtape] = useState(seanceId ? "reprise" : "accueil");
  // Message d'information sur l'écran d'accueil (séance précédente close entre-temps).
  const [info, setInfo] = useState(null);
  const [question, setQuestion] = useState(null);
  const [saisie, setSaisie] = useState("");
  const [resultat, setResultat] = useState(null);
  const [bilan, setBilan] = useState(() => lire(CLE_BILAN) ?? BILAN_VIDE);
  const [erreur, setErreur] = useState(null);
  const [envoi, setEnvoi] = useState(false);
  // Compétence visée par la séance en cours (séance lancée depuis une leçon ou l'historique).
  const [competenceVisee, setCompetenceVisee] = useState(() => lire(CLE_CIBLE));
  // Ticket #26 : révision demandée par l'élève (les questions déjà réussies reviennent) et motif d'épuisement.
  const [revision, setRevision] = useState(false);
  const [epuisement, setEpuisement] = useState(null);
  const champ = useRef(null);

  function changerSeance(id, visee = null) {
    ecrire(CLE_SEANCE, id);
    ecrire(CLE_CIBLE, visee);
    setSeanceId(id);
    setCompetenceVisee(visee);
    setRevision(false);
  }

  async function appeler(chemin, options) {
    setErreur(null);
    setEnvoi(true);
    try {
      return await api(chemin, { ...options, jeton });
    } catch (err) {
      if (err.status === 401) onExpire();
      throw err;
    } finally {
      setEnvoi(false);
    }
  }

  async function chargerQuestion(id, enRevision = revision) {
    try {
      const q = await appeler(`/seances/${id}/question${enRevision ? "?revision=true" : ""}`);
      setResultat(null);
      setSaisie("");
      if (q === null) {
        setEpuisement(await appeler(`/seances/${id}/epuisement`).catch(() => null));
        setEtape("epuise");
      } else {
        setQuestion(q);
        setEtape("question");
      }
    } catch (err) {
      if (err.status === 404 || err.status === 409) {
        // Séance terminée ou introuvable (autre appareil, purge…) : on repart de zéro.
        changerSeance(null);
        setInfo("Ta séance précédente est terminée : choisis tes chapitres pour en commencer une nouvelle.");
        setEtape("accueil");
      } else if (err.status !== 401) {
        setErreur(err.message);
      }
    }
  }

  /** Même exercice, autres nombres : surtout utile après une erreur, pour refaire tout de suite. */
  async function refaireAvecDAutresNombres() {
    try {
      const q = await appeler(`/seances/${seanceId}/variante`, { methode: "POST", corps: { question_id: question.id } });
      setResultat(null);
      setSaisie("");
      setQuestion(q);
      setEtape("question");
    } catch (err) {
      if (err.status !== 401) setErreur(err.message);
    }
  }

  /** Reprise de la séance mémorisée : même séance, même question en cours (l'API la garde). */
  function reprendre() {
    setInfo(null);
    chargerQuestion(seanceId); // l'écran reste affiché, bouton désactivé, jusqu'à la question
  }

  useEffect(() => {
    if (etape === "question") champ.current?.focus();
  }, [etape, question]);

  // Le compteur suit la séance mémorisée : un rechargement ne le remet pas à zéro.
  useEffect(() => {
    ecrire(CLE_BILAN, bilan);
  }, [bilan]);

  // Chapitres ouverts par le professeur ; par défaut, tous ceux qui ont des questions sont cochés.
  const [chapitres, setChapitres] = useState(null);
  const [coches, setCoches] = useState(new Set());

  useEffect(() => {
    if (etape !== "accueil" && etape !== "bilan") return;
    let actif = true;
    api("/eleves/moi/chapitres", { jeton }).then(
      (liste) => {
        if (!actif) return;
        setChapitres(liste);
        setCoches(new Set(liste.filter((c) => c.nb_questions > 0).map((c) => c.id)));
      },
      (err) => actif && (err.status === 401 ? onExpire() : setErreur(err.message)),
    );
    return () => {
      actif = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [etape, jeton]);

  function basculer(id) {
    setCoches((avant) => {
      const apres = new Set(avant);
      apres.has(id) ? apres.delete(id) : apres.add(id);
      return apres;
    });
  }

  async function demarrer(corps = { chapitre_ids: [...coches] }, visee = null) {
    try {
      // « Choisir un autre chapitre » alors qu'une séance était en cours : elle est close (ses réponses restent
      // dans l'historique) avant d'en ouvrir une autre, comme pour un entrainement ciblé.
      if (seanceId && !visee) await api(`/seances/${seanceId}/fin`, { methode: "POST", jeton }).catch(() => {});
      setInfo(null);
      const seance = await appeler("/seances", { methode: "POST", corps });
      changerSeance(seance.id, visee);
      setBilan(BILAN_VIDE);
      await chargerQuestion(seance.id);
    } catch (err) {
      if (err.status !== 401) setErreur(err.message);
    }
  }

  // « S'entraîner sur cette compétence » : la séance en cours est close (ses réponses restent
  // dans l'historique), puis une séance ciblée démarre.
  useEffect(() => {
    if (!cible) return;
    (async () => {
      if (seanceId) await api(`/seances/${seanceId}/fin`, { methode: "POST", jeton }).catch(() => {});
      const niveaux = cible.niveaux ? { difficulte_min: cible.niveaux.min, difficulte_max: cible.niveaux.max } : {};
      await demarrer({ competence_ids: [cible.id], ...niveaux }, { id: cible.id, libelle: cible.libelle, niveaux: cible.niveaux });
    })();
    // Uniquement quand une nouvelle demande arrive (cible.n change).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cible?.n]);

  async function repondre(valeur) {
    try {
      const r = await appeler(`/seances/${seanceId}/reponses`, {
        methode: "POST",
        corps: { question_id: question.id, reponse_donnee: valeur },
      });
      setSaisie(valeur);
      setResultat(r);
      setBilan((b) => ({ reponses: b.reponses + 1, reussies: b.reussies + (r.correcte ? 1 : 0) }));
      setEtape("resultat");
    } catch (err) {
      if (err.status === 409) await chargerQuestion(seanceId);
      else if (err.status !== 401) setErreur(err.message);
    }
  }

  async function terminer() {
    try {
      await appeler(`/seances/${seanceId}/fin`, { methode: "POST" });
    } catch (err) {
      if (err.status === 401) return;
      // 404/409 : déjà terminée ailleurs, on affiche quand même le bilan.
    }
    changerSeance(null);
    setEtape("bilan");
  }

  if (etape === "reprise") {
    return (
      <section className="carte accueil-seance" aria-labelledby="titre-reprise">
        <h2 id="titre-reprise">Ta séance t'attend</h2>
        <p className="doux">
          {bilan.reponses > 0
            ? `Tu as déjà répondu à ${bilan.reponses} question${bilan.reponses > 1 ? "s" : ""} dans cette séance. `
            : ""}
          Tu reprends exactement là où tu t'étais arrêté·e.
          {competenceVisee && (
            <>
              {" "}
              Entrainement ciblé : <strong>{competenceVisee.libelle}</strong>.
            </>
          )}
        </p>
        <Erreur message={erreur} />
        <div className="actions">
          <button onClick={reprendre} disabled={envoi}>
            Reprendre ma séance
          </button>
          <button className="secondaire" onClick={() => setEtape("accueil")} disabled={envoi}>
            Choisir un autre chapitre
          </button>
        </div>
        <ConseilsTravail />
      </section>
    );
  }

  if (etape === "accueil" || etape === "bilan") {
    return (
      <section className="carte accueil-seance">
        {etape === "bilan" ? (
          <>
            <h2>Séance terminée</h2>
            <p>
              {bilan.reponses === 0
                ? "Aucune réponse cette fois-ci."
                : `${bilan.reussies} bonne${bilan.reussies > 1 ? "s" : ""} réponse${bilan.reussies > 1 ? "s" : ""} sur ${bilan.reponses}.`}
            </p>
          </>
        ) : (
          <>
            <h2>Prêt·e à t'entraîner ?</h2>
            <p className="doux">
              Les chapitres ouverts par ton professeur sont déjà cochés : tu peux commencer tout de suite, ou n'en garder que
              certains. Les questions s'adaptent à ton niveau : on travaille d'abord ce qui est le moins maîtrisé.
            </p>
          </>
        )}
        {info && <p className="info petit">{info}</p>}
        <Erreur message={erreur} />
        <div className="actions">
          <button onClick={() => demarrer()} disabled={envoi || coches.size === 0}>
            {etape === "bilan" ? "Nouvelle séance" : "Commencer à travailler"}
          </button>
          {seanceId && etape === "accueil" && (
            <button className="secondaire" onClick={reprendre} disabled={envoi}>
              Reprendre ma séance
            </button>
          )}
        </div>
        {chapitres === null ? (
          <p className="doux">Chargement des chapitres…</p>
        ) : chapitres.length === 0 ? (
          <p className="doux">Ton professeur n'a pas encore ouvert de chapitre.</p>
        ) : (
          <fieldset className="choix-chapitres">
            <legend>Chapitres à travailler</legend>
            {chapitres.map((c) => (
              <label key={c.id} className="case">
                <input
                  type="checkbox"
                  checked={coches.has(c.id)}
                  onChange={() => basculer(c.id)}
                  disabled={c.nb_questions === 0}
                />
                {c.titre}
                <span className="doux">
                  {c.nb_questions === 0 ? " (bientôt disponible)" : ` (${c.nb_questions} question${c.nb_questions > 1 ? "s" : ""})`}
                </span>
              </label>
            ))}
          </fieldset>
        )}
        <ConseilsTravail />
      </section>
    );
  }

  if (etape === "chargement") return <p className="doux">Chargement…</p>;

  const enCours = (
    <div className="bilan" aria-live="polite">
      <span>
        Réponses : <strong>{bilan.reponses}</strong>
      </span>
      <span>
        Réussies : <strong>{bilan.reussies}</strong>
      </span>
    </div>
  );

  if (etape === "epuise") {
    return (
      <section className="carte">
        <h2>Plus de question disponible</h2>
        {epuisement?.motif === "toutes-reussies" ? (
          <p className="doux">
            Tu as réussi toutes les questions de cette séance : elles ne reviendront pas tout de suite. Tu peux les réviser
            maintenant, ou terminer la séance et choisir d'autres chapitres.
          </p>
        ) : (
          <p className="doux">Ton professeur n'a pas encore ajouté de questions pour ton niveau.</p>
        )}
        <Erreur message={erreur} />
        <div className="actions">
          {epuisement?.motif === "toutes-reussies" && (
            <button
              className="secondaire"
              onClick={() => {
                setRevision(true);
                chargerQuestion(seanceId, true);
              }}
            >
              Réviser les questions réussies
            </button>
          )}
          <button onClick={terminer}>Terminer la séance</button>
        </div>
      </section>
    );
  }

  const { intitule, options } = question.type === "qcm" ? decouperQcm(question.enonce) : { intitule: question.enonce, options: null };
  const repondue = etape === "resultat";

  return (
    <>
      {enCours}
      {competenceVisee && (
        <p className="info petit">
          Entrainement ciblé : <strong>{competenceVisee.libelle}</strong>
          {competenceVisee.niveaux &&
            ` · niveaux ${competenceVisee.niveaux.min} ${competenceVisee.niveaux.max - competenceVisee.niveaux.min > 1 ? "à" : "et"} ${competenceVisee.niveaux.max}`}
        </p>
      )}
      <article className="carte">
        <div className="meta">
          <span className="badge">{LIBELLES_TYPE[question.type]}</span>
          <Difficulte niveau={question.difficulte} />
          {question.en_relecture && (
            <span className="badge alerte" title="Cette question n'a pas encore été relue par un professeur : en cas de doute, signale-la à ton professeur.">
              En relecture
            </span>
          )}
        </div>
        <p className="enonce">
          <Maths enLigne texte={intitule} />
        </p>

        {options ? (
          <div className="options">
            {options.map((o) => (
              <button key={o.lettre} onClick={() => repondre(o.lettre)} disabled={envoi || repondue}>
                <span className="lettre">{o.lettre}</span>
                <Maths enLigne texte={o.texte} />
              </button>
            ))}
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (saisie.trim()) repondre(saisie);
            }}
          >
            <label htmlFor="saisie">Ta réponse</label>
            <input
              id="saisie"
              ref={champ}
              value={saisie}
              onChange={(e) => setSaisie(e.target.value)}
              readOnly={repondue}
              autoComplete="off"
              spellCheck={false}
              maxLength={200}
            />
            <p className="aide">{AIDE[question.type]}</p>
            {!repondue && (
              <div className="actions">
                <button type="submit" disabled={envoi || !saisie.trim()}>
                  Valider
                </button>
              </div>
            )}
          </form>
        )}
        <Erreur message={erreur} />
        {!repondue && (
          <p className="aide conseil">
            {CONSEILS.essayer}
            {onVoirCours && (
              <>
                {" "}
                <button className="lien" onClick={() => onVoirCours(question.competence_id)}>
                  Relire le cours de cette notion
                </button>
              </>
            )}
          </p>
        )}
      </article>

      {repondue && (
        <article className={`carte resultat ${resultat.correcte ? "ok" : "ko"}`} role="status">
          <p className="verdict">{resultat.correcte ? "Bonne réponse !" : "Pas tout à fait."}</p>
          {resultat.remarque && <p className="avertissement">{resultat.remarque}</p>}
          {!resultat.correcte && <p className="aide conseil">{CONSEILS.erreur}</p>}
          {!resultat.correcte && (
            <p>
              Réponse attendue : <code>{solutionLisible(question.type, resultat.solution)}</code>
            </p>
          )}
          <Correction
            correction={resultat.correction}
            references={
              onVoirCours && {
                competence: resultat.competence,
                methodes: resultat.methodes,
                onVoir: (ancre) => onVoirCours(question.competence_id, { ancre }),
              }
            }
          />
          <AideExercice
            key={question.id}
            seanceId={seanceId}
            questionId={question.id}
            jeton={jeton}
            avecCorrection={Boolean(resultat.correction)}
          />
          {!resultat.correction && resultat.rappel && (
            <details className="correction" open={!resultat.correcte}>
              <summary>Partie du cours à utiliser : {resultat.competence}</summary>
              <p className="doux petit">
                La correction pas à pas de cette question n'est pas encore rédigée. Voici l'essentiel du cours à appliquer :
              </p>
              <section className="resume">
                <Maths texte={resultat.rappel} />
              </section>
            </details>
          )}
          <BarreMaitrise valeur={resultat.maitrise} maitrisee={resultat.maitrisee} libelle="Maîtrise de cette compétence" />
          <div className="actions">
            {question.variable && !resultat.correcte && (
              <button autoFocus onClick={refaireAvecDAutresNombres} disabled={envoi}>
                Refaire avec d'autres nombres
              </button>
            )}
            <button
              autoFocus={!(question.variable && !resultat.correcte)}
              className={question.variable && !resultat.correcte ? "secondaire" : undefined}
              onClick={() => chargerQuestion(seanceId)}
              disabled={envoi}
            >
              Question suivante
            </button>
            {question.variable && resultat.correcte && (
              <button className="secondaire" onClick={refaireAvecDAutresNombres} disabled={envoi}>
                Encore un, avec d'autres nombres
              </button>
            )}
            {onVoirCours && (
              <button className="secondaire" onClick={() => onVoirCours(question.competence_id)}>
                Revoir le cours
              </button>
            )}
            <button className="lien" onClick={terminer} disabled={envoi}>
              Terminer la séance
            </button>
          </div>
        </article>
      )}

      {!repondue && (
        <div className="actions">
          <button className="lien" onClick={terminer} disabled={envoi}>
            Terminer la séance
          </button>
        </div>
      )}
    </>
  );
}

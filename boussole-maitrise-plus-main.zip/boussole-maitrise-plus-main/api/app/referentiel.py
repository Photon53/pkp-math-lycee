"""Vocabulaire du référentiel : parcours (spécialités), traçabilité des sources, validation.

La banque s'ordonne ainsi : niveau (classe) → parcours (spécialité) → chapitre (cours)
→ compétence → difficulté (1 à 5).
"""

from enum import Enum

from pkp_engine import Niveau


class Parcours(str, Enum):
    TRONC_COMMUN = "tronc-commun"  # Collège et seconde : enseignement commun de mathématiques
    SPECIALITE = "specialite"  # Première et Terminale : spécialité mathématiques
    COMPLEMENTAIRES = "complementaires"  # Terminale : option mathématiques complémentaires
    EXPERTES = "expertes"  # Terminale : option mathématiques expertes
    SCIENTIFIQUE = "scientifique"  # Première : mathématiques de l'enseignement scientifique (sans la spécialité)
    TECHNOLOGIQUE = "technologique"  # Première et Terminale : voie technologique (STMG, STI2D, STL, ST2S…)
    # Seconde : voie professionnelle (seconde préparant au bac pro, BO spécial n° 5 du 11 avril 2019).
    # À ne pas confondre avec la voie technologique ; programme distinct de la seconde générale.
    PROFESSIONNEL = "professionnel"
    EXCELLENCE = "excellence"  # Tous niveaux : exercices très poussés et olympiades (groupe d'approfondissement)
    MISE_A_NIVEAU = "mise-a-niveau"  # Tous niveaux : vérifier les bases de l'année précédente (groupe de soutien)
    EXAMENS = "examens"  # 3e : brevet ; 1re et Tle : épreuve anticipée, bac blanc, sujets type annales


# Parcours principal d'un élève en maths, un par niveau : l'enseignement qu'il suit (V3, Lot 1). Les autres
# parcours (excellence, mise à niveau, examens, maths expertes) sont des options qui s'y ajoutent.
PARCOURS_PRINCIPAUX: frozenset[Parcours] = frozenset({
    Parcours.TRONC_COMMUN, Parcours.SPECIALITE, Parcours.SCIENTIFIQUE, Parcours.TECHNOLOGIQUE, Parcours.COMPLEMENTAIRES,
    Parcours.PROFESSIONNEL,
})


def est_principal(parcours: "Parcours | str") -> bool:
    return Parcours(parcours) in PARCOURS_PRINCIPAUX


PARCOURS_PAR_NIVEAU: dict[Niveau, tuple[Parcours, ...]] = {
    # Collège : un programme commun ; soutien et approfondissement ; en 3e, préparation au brevet.
    Niveau.SIXIEME: (Parcours.TRONC_COMMUN, Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE),
    Niveau.CINQUIEME: (Parcours.TRONC_COMMUN, Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE),
    Niveau.QUATRIEME: (Parcours.TRONC_COMMUN, Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE),
    Niveau.TROISIEME: (Parcours.TRONC_COMMUN, Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE, Parcours.EXAMENS),
    # Le tronc commun reste le parcours par défaut (seconde générale et technologique) : rien ne change pour
    # les classes existantes. La voie professionnelle n'est jamais attribuée sans choix explicite.
    Niveau.SECONDE: (Parcours.TRONC_COMMUN, Parcours.PROFESSIONNEL, Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE),
    Niveau.PREMIERE: (
        Parcours.SPECIALITE, Parcours.SCIENTIFIQUE, Parcours.TECHNOLOGIQUE,
        Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE, Parcours.EXAMENS,
    ),
    Niveau.TERMINALE: (
        Parcours.SPECIALITE, Parcours.COMPLEMENTAIRES, Parcours.EXPERTES, Parcours.TECHNOLOGIQUE,
        Parcours.MISE_A_NIVEAU, Parcours.EXCELLENCE, Parcours.EXAMENS,
    ),
}

LIBELLES_PARCOURS = {
    Parcours.TRONC_COMMUN: "Tronc commun",
    Parcours.SPECIALITE: "Spécialité",
    Parcours.COMPLEMENTAIRES: "Maths complémentaires",
    Parcours.EXPERTES: "Maths expertes",
    Parcours.SCIENTIFIQUE: "Enseignement scientifique",
    Parcours.TECHNOLOGIQUE: "Voie technologique",
    Parcours.PROFESSIONNEL: "Voie professionnelle",
    Parcours.EXCELLENCE: "Excellence et olympiades",
    Parcours.MISE_A_NIVEAU: "Mise à niveau",
    Parcours.EXAMENS: "Préparation aux examens",
}


# Abréviation du parcours dans le code d'une classe (« TLE-EXP-4KQ7M ») : on devine la spécialité au premier coup d'œil.
ABREVIATIONS_PARCOURS = {
    Parcours.TRONC_COMMUN: "TC",
    Parcours.SPECIALITE: "SPE",
    Parcours.SCIENTIFIQUE: "ES",
    Parcours.COMPLEMENTAIRES: "COMP",
    Parcours.EXPERTES: "EXP",
    Parcours.TECHNOLOGIQUE: "TECH",
    Parcours.PROFESSIONNEL: "PRO",
    Parcours.MISE_A_NIVEAU: "MAN",
    Parcours.EXCELLENCE: "EXC",
    Parcours.EXAMENS: "EXAM",
}


NIVEAUX_COLLEGE = (Niveau.SIXIEME, Niveau.CINQUIEME, Niveau.QUATRIEME, Niveau.TROISIEME)


def domaine_maths(niveau: Niveau) -> str:
    """Domaine pédagogique d'une classe ou d'un chapitre de maths : Maths collège ou Maths lycée (CDC V2, EX.2)."""
    return "maths-college" if niveau in NIVEAUX_COLLEGE else "maths-lycee"


# Matières d'une classe (espace des classes). Le français suit le tronc commun, de la 6e à la 1re.
MATIERES_CLASSES = ("maths", "francais")
NIVEAUX_FRANCAIS = (*NIVEAUX_COLLEGE, Niveau.SECONDE, Niveau.PREMIERE)


def refus_matiere(matiere: str, niveau: Niveau, parcours: "Parcours | None") -> str | None:
    """Motif du refus d'une classe ou d'un chapitre de cette matière à ce niveau, ou None."""
    if matiere == "francais":
        if niveau not in NIVEAUX_FRANCAIS:
            return f"Le français n'est pas enseigné en {niveau.value} dans Boussole."
        if parcours not in (None, Parcours.TRONC_COMMUN):
            return "Une classe ou un chapitre de français suit le tronc commun."
    return None


def domaine_de(matiere: str, niveau: Niveau) -> str:
    """Domaine pédagogique d'une classe ou d'un chapitre (CDC V2, EX.2)."""
    if matiere == "francais":
        return "francais-college" if niveau in NIVEAUX_COLLEGE else "francais-lycee"
    return domaine_maths(niveau)


def matiere_du_domaine(domaine: str) -> str:
    return domaine.split("-", 1)[0]


def parcours_par_defaut(niveau: Niveau) -> Parcours:
    return PARCOURS_PAR_NIVEAU[niveau][0]


class Adaptation(str, Enum):
    """Lien entre une question et sa source (registre des sources)."""

    ORIGINALE = "originale"  # rédigée pour PKP, sans source
    INSPIREE = "inspiree"  # idée reprise, énoncé et valeurs entièrement réécrits
    ADAPTEE = "adaptee"  # texte d'une source modifié : la licence de la source s'applique
    REPRODUITE = "reproduite"  # texte d'une source repris, avec autorisation ou licence libre


class RubriqueFrancais(str, Enum):
    """Rubrique d'un chapitre de français (issue #177, décision du propriétaire du 19/11/2026) : une seule interface
    Français, quatre rubriques, indépendantes des niveaux. Les chapitres de maths n'en ont pas."""

    CONJUGAISON = "conjugaison"
    GRAMMAIRE = "grammaire"
    REDACTION = "redaction"
    MON_COURS = "mon_cours"


class NatureChapitre(str, Enum):
    """Rôle d'un chapitre (issue #162). Un chapitre de diagnostic repère les acquis des années précédentes :
    il n'est jamais ouvert comme un chapitre d'entraînement, et ses réponses ne comptent pas dans la maîtrise."""

    APPRENTISSAGE = "apprentissage"
    DIAGNOSTIC = "diagnostic"


class StatutObservation(str, Enum):
    """Résultat d'une réponse de diagnostic : corrigée par le moteur, ou en attente d'un professeur."""

    JUSTE = "juste"
    FAUX = "faux"
    NE_SAIT_PAS = "je-ne-sais-pas"  # distinct d'une réponse fausse (lot 3)
    EN_ATTENTE = "en-attente-de-correction"


class StatutValidation(str, Enum):
    A_VALIDER = "a-valider"
    VALIDEE = "validee"
    A_CORRIGER = "a-corriger"


SOURCE_PKP = "PKP Math"


class Role(str, Enum):
    ENSEIGNANT = "enseignant"
    ADMIN = "admin"


class TypeRessource(str, Enum):
    LIEN = "lien"
    PDF = "pdf"


class PorteeRessource(str, Enum):
    COMMUNE = "commune"  # ajoutée par un administrateur, pour tous
    CLASSE = "classe"  # ajoutée par un professeur, pour les classes qu'il choisit


class PublicRessource(str, Enum):
    TOUS = "tous"
    ELEVES = "eleves"
    ENSEIGNANTS = "enseignants"

# Une source sans licence claire ne peut servir que d'inspiration (jamais adaptée ni reproduite).
LICENCES_NON_CLAIRES = {"", "aucune", "inconnue", "non clarifiée", "non clarifiee", "a verifier", "à vérifier"}

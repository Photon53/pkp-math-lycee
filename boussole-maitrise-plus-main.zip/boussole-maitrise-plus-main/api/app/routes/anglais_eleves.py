"""Espace élève PKP Anglais : connexion par identifiant + code, séances validées, quiz corrigés, « I can ».

Seules les versions validées par un référent sont ouvertes aux élèves (CDC anglais V1.8).
Les corrigés ne quittent jamais le serveur avant l'envoi des réponses.
"""
from typing import Annotated, Literal

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app import anglais_contenu, limitation, permissions
from app.auth import CARTE_BLOQUEE, CLASSE_ARCHIVEE, ELEVE_ANGLAIS, EleveAnglaisCourant, SessionDB, carte_bloquee
from app.config import settings
from app.db import models
from app.routes.eleves import ECHEC_IDENTIFIANT, _code_leurre
from app.schemas import ConnexionIdentifiant
from app.security import creer_jeton, normaliser_identifiant, verifier_code_eleve, version_mot_de_passe

router = APIRouter(prefix="/anglais/eleve", tags=["anglais-eleve"])


class EleveAnglaisInfo(BaseModel):
    prenom: str
    niveau: str
    groupe: str


class JetonEleveAnglais(BaseModel):
    jeton: str
    eleve: EleveAnglaisInfo


class Reponses(BaseModel):
    # Index du choix retenu pour chaque question, dans l'ordre ; None = sans réponse.
    reponses: Annotated[list[int | None], Field(max_length=50)]


class AutoEvaluation(BaseModel):
    i_can: Annotated[list[Literal[anglais_contenu.NIVEAUX_I_CAN]], Field(max_length=10)]  # type: ignore[valid-type]


def _info(eleve: models.EleveAnglais) -> EleveAnglaisInfo:
    return EleveAnglaisInfo(prenom=eleve.prenom, niveau=eleve.groupe.niveau, groupe=eleve.groupe.nom)


@router.post("/connexion", response_model=JetonEleveAnglais)
def connexion(corps: ConnexionIdentifiant, request: Request, session: SessionDB) -> JetonEleveAnglais:
    """Identifiant + code personnel imprimés sur la carte : mêmes protections que l'espace de maths."""
    ip = limitation.adresse_ip(request)
    identifiant = normaliser_identifiant(corps.identifiant)
    compte = f"eleve-anglais:{identifiant}"
    limitation.verifier((limitation.par_ip, ip), (limitation.codes_inconnus, ip), (limitation.echecs_code_eleve, compte), (limitation.echecs_eleve_par_ip, ip))
    limitation.par_ip.enregistrer(ip)

    eleve = session.scalar(select(models.EleveAnglais).where(func.lower(models.EleveAnglais.identifiant) == identifiant))
    empreinte = eleve.code_hash if eleve and eleve.code_hash else _code_leurre()  # même durée dans tous les cas
    if not verifier_code_eleve(corps.code_personnel, empreinte) or not (eleve and eleve.code_hash):
        if eleve is None:
            limitation.codes_inconnus.enregistrer(ip)  # freine la recherche d'identifiants
        limitation.echecs_code_eleve.enregistrer(compte)
        limitation.echecs_eleve_par_ip.enregistrer(ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, ECHEC_IDENTIFIANT)
    limitation.echecs_code_eleve.effacer(compte)
    if carte_bloquee(eleve):
        raise HTTPException(status.HTTP_403_FORBIDDEN, CARTE_BLOQUEE)
    if not eleve.groupe.enseignant.actif:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Le compte de ton professeur est suspendu.")
    if eleve.groupe.archivee_le is not None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, CLASSE_ARCHIVEE)
    duree_h = settings.duree_jeton_eleve_longue_j * 24 if corps.rester_connecte else settings.duree_jeton_eleve_h
    jeton = creer_jeton(ELEVE_ANGLAIS, eleve.id, duree_h, version_mot_de_passe(eleve.code_hash))
    return JetonEleveAnglais(jeton=jeton, eleve=_info(eleve))


@router.get("/moi", response_model=EleveAnglaisInfo)
def moi(eleve: EleveAnglaisCourant) -> EleveAnglaisInfo:
    return _info(eleve)


def _publiee(session: SessionDB, eleve: models.EleveAnglais, code: str) -> models.SeanceAnglaisVersion:
    """Version validée d'une séance du niveau de l'élève ; sinon 404 (rien ne trahit un brouillon).
    Domaine fermé au public : 403, sans rien supprimer (EX.4)."""
    groupe = eleve.groupe
    refus = permissions.refus_domaine_ferme(session, groupe.domaine_code)
    if refus:
        raise HTTPException(status.HTTP_403_FORBIDDEN, refus)
    seance = anglais_contenu.par_code(session, code)
    version = (
        seance and seance.domaine_code == groupe.domaine_code and seance.niveau == groupe.niveau and seance.publiee
    )
    if not version:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Séance introuvable.")
    return version


def _progression(session: SessionDB, eleve: models.EleveAnglais, code: str) -> models.ProgressionAnglais:
    p = next((p for p in eleve.progression if p.code == code), None)
    if p is None:
        p = models.ProgressionAnglais(code=code, meilleur_score=0, total=0, tentatives=0, i_can=[])
        eleve.progression.append(p)
    return p


@router.get("/seances")
def mes_seances(eleve: EleveAnglaisCourant, session: SessionDB):
    """Séances validées de son niveau, avec sa progression."""
    suivi = {p.code: p for p in eleve.progression}
    lignes = []
    for s in anglais_contenu.toutes(session):
        v = s.publiee
        if s.niveau != eleve.groupe.niveau or v is None:
            continue
        p = suivi.get(s.code)
        lignes.append({
            "code": s.code, "titre": v.contenu["title"], "objectif": v.contenu["objective"],
            "can_do": v.cahier.get("can_do", []),
            "score": p.meilleur_score if p else None, "total": p.total if p else None,
            "tentatives": p.tentatives if p else 0, "i_can": p.i_can if p else [],
        })
    return lignes


@router.get("/seances/{code}")
def ma_seance(code: str, eleve: EleveAnglaisCourant, session: SessionDB):
    p = next((p for p in eleve.progression if p.code == code), None)
    version = _publiee(session, eleve, code)
    return {**anglais_contenu.vue_eleve(version), "i_can": p.i_can if p else [],
            "mode_correction": eleve.groupe.mode_correction_de(version.seance.code)}


@router.post("/seances/{code}/corriger")
def corriger(code: str, corps: Reponses, eleve: EleveAnglaisCourant, session: SessionDB):
    """Correction immédiate ; seul le meilleur score est conservé.

    ARCH-4 (décision du propriétaire du 14/11/2026, #107) : le corrigé n'est rendu qu'une fois chaque question
    répondue par un choix existant ; un envoi vide ou partiel est refusé, sans rien enregistrer."""
    version = _publiee(session, eleve, code)
    quiz = anglais_contenu.quiz_complet(version)
    if len(corps.reponses) != len(quiz) or any(
        r is None or not 0 <= r < len(q["choix"]) for r, q in zip(corps.reponses, quiz, strict=False)
    ):
        raise HTTPException(422, "Réponds à toutes les questions avant de voir la correction.")
    resultat = anglais_contenu.corriger(version, corps.reponses)
    p = _progression(session, eleve, code)
    if p.tentatives == 0:
        # Score du premier essai, figé (#110, choix B) ; inconnu pour les résultats d'avant ce suivi.
        p.premier_score = resultat["score"]
    p.tentatives += 1
    p.total = resultat["total"]
    p.meilleur_score = max(p.meilleur_score, resultat["score"])
    # Réponses de cet essai, question par question (#110).
    for i, (choix, detail) in enumerate(zip(corps.reponses, resultat["details"], strict=True)):
        eleve.reponses.append(models.ReponseAnglais(
            code=version.seance.code, essai=p.tentatives, question=i, choix=choix, juste=detail["juste"],
        ))
    session.commit()
    return {**resultat, "meilleur_score": p.meilleur_score, "premier_score": p.premier_score}


@router.put("/seances/{code}/i-can")
def auto_evaluer(code: str, corps: AutoEvaluation, eleve: EleveAnglaisCourant, session: SessionDB):
    version = _publiee(session, eleve, code)
    if len(corps.i_can) != len(version.cahier.get("can_do", [])):
        raise HTTPException(422, "Une réponse par phrase « I can » est attendue.")
    p = _progression(session, eleve, code)
    p.i_can = list(corps.i_can)
    session.commit()
    return {"i_can": p.i_can}

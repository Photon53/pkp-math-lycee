"""Cours et résumés, consultables par les élèves (chapitres ouverts de leur classe uniquement)."""

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app import ressources
from app.auth import EleveCourant, SessionDB
from app.db import models
from app.progression import ids_ouverts_eleve
from app.schemas import ChapitreCours, ChapitreMonCours, CompetenceCours, LeconInfo

router = APIRouter(prefix="/cours", tags=["cours"])


@router.get("", response_model=list[ChapitreCours])
def sommaire(eleve: EleveCourant, session: SessionDB) -> list[ChapitreCours]:
    chapitres = session.scalars(
        select(models.Chapitre)
        .where(models.Chapitre.id.in_(ids_ouverts_eleve(session, eleve.classe)))
        .options(selectinload(models.Chapitre.competences).selectinload(models.Competence.lecon))
        .order_by(models.Chapitre.ordre)
    )
    return [
        ChapitreCours(
            id=ch.id,
            code=ch.code,
            titre=ch.titre,
            rubrique=ch.rubrique.value if ch.rubrique else None,
            competences=[
                CompetenceCours(id=c.id, code=c.code, libelle=c.libelle, a_une_lecon=c.lecon is not None)
                for c in sorted(ch.competences, key=lambda c: (c.ordre, c.code))
                if not c.masque
            ],
        )
        for ch in chapitres
    ]


@router.get("/mon-cours", response_model=list[ChapitreMonCours])
def mon_cours(eleve: EleveCourant, session: SessionDB) -> list[ChapitreMonCours]:
    """Issue #180 : « Mon cours » suit l'avancée du cours. Chapitres ouverts par le professeur, dans l'ordre, et les
    fiches et liens qu'il y a rattachés pour la classe ; mêmes règles d'accès que le reste des cours (#176)."""
    ouverts = set(ids_ouverts_eleve(session, eleve.classe))
    chapitres = sorted((c for c in eleve.classe.chapitres_proposes if c.id in ouverts), key=lambda c: c.ordre)
    par_chapitre = ressources.par_chapitre_pour_eleve(session, eleve, ouverts)
    return [ChapitreMonCours(id=c.id, titre=c.titre, ressources=par_chapitre[c.id]) for c in chapitres]


@router.get("/{competence_id}", response_model=LeconInfo)
def lecon(competence_id: int, eleve: EleveCourant, session: SessionDB) -> LeconInfo:
    competence = session.get(models.Competence, competence_id)
    if (
        competence is None
        or competence.lecon is None
        or competence.masque
        or competence.chapitre_id not in ids_ouverts_eleve(session, eleve.classe)
    ):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Cours introuvable.")
    return LeconInfo(
        competence_id=competence.id,
        code=competence.code,
        libelle=competence.libelle,
        chapitre=competence.chapitre.titre,
        chapitre_id=competence.chapitre_id,
        cours=competence.lecon.cours,
        resume=competence.lecon.resume,
        objectifs=competence.objectifs or [],
        methodes=competence.methodes or [],
        erreurs_frequentes=competence.erreurs_frequentes or [],
        ressources=ressources.pour_eleve(session, eleve, None, competence.id)
        + ressources.pour_eleve(session, eleve, competence.chapitre_id, None),
    )

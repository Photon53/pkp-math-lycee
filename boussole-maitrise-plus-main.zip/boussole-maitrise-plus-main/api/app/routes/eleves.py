"""Parcours élève : connexion → séance → question → réponse → question…

Une séance n'a qu'une question en cours à la fois. Redemander la question
suivante renvoie la même tant qu'elle n'a pas reçu de réponse : impossible de
« passer » une question difficile, ou de répondre à une question non servie.
"""

from datetime import UTC, datetime
from functools import cache

from fastapi import APIRouter, HTTPException, Request, Response, status
from pkp_engine import (
    ESPACEMENT_REVISION,
    Question,
    TypeQuestion,
    Verdict,
    calculer_maitrise,
    choisir_prochaine_question,
    corrige_automatiquement,
    est_maitrisee,
    questions_au_repos,
    verifier,
)
from pkp_engine.formes import LIBELLES as LIBELLES_FORMES
from sqlalchemy import String, and_, cast, func, select

from app import exemplaires, inscriptions, limitation, permissions
from app.auth import CARTE_BLOQUEE, CLASSE_ARCHIVEE, ELEVE, EleveCourant, SessionDB, carte_bloquee
from app.config import settings
from app.db import models
from app.db.conversions import historique_eleve, question_vers_domaine
from app.progression import (
    filtre_apprentissage,
    filtre_validation,
    est_apprentissage,
    avancement_competence,
    historique_reponses,
    ids_ouverts,
    ids_ouverts_eleve,
    nb_questions_servables,
    progression_eleve,
    validees_en_priorite,
)
from app.schemas import (
    AvancementCompetence,
    ChapitreOuvert,
    ConnexionEleve,
    ConnexionIdentifiant,
    DemandeVariante,
    Epuisement,
    PageHistorique,
    EleveInfo,
    InscriptionLiee,
    JetonEleve,
    ProgressionCompetence,
    QuestionPublique,
    ResultatReponse,
    SeanceCreation,
    SeanceInfo,
    SoumissionReponse,
)
from app.security import (
    creer_jeton,
    generer_code_eleve,
    hacher_code_eleve,
    normaliser_identifiant,
    verifier_code_eleve,
    version_mot_de_passe,
)

router = APIRouter(tags=["élève"])


def _maintenant() -> datetime:
    return datetime.now(UTC)


def _utc(instant: datetime) -> datetime:
    # SQLite rend des dates sans fuseau : elles ont été enregistrées en UTC.
    return instant if instant.tzinfo else instant.replace(tzinfo=UTC)


def _info(eleve: models.Eleve) -> EleveInfo:
    return EleveInfo(
        id=eleve.id,
        prenom=eleve.prenom,
        identifiant=eleve.identifiant or (eleve.enfant.identifiant if eleve.enfant else None),
        code_classe=eleve.classe.code,
        niveau=eleve.classe.niveau,
        parcours=eleve.classe.parcours,
        matiere=eleve.classe.domaine_code.split("-", 1)[0],
    )


ECHEC_CONNEXION = "Prénom, code classe ou code personnel incorrect."
ECHEC_IDENTIFIANT = "Identifiant ou code personnel incorrect."


@cache
def _code_leurre() -> str:
    return hacher_code_eleve(generer_code_eleve())


@router.post("/eleves/connexion", response_model=JetonEleve)
def connexion(corps: ConnexionEleve, request: Request, session: SessionDB) -> JetonEleve:
    """Prénom + code classe + code personnel (distribué par l'enseignant).

    Les comptes sont créés par l'enseignant : il n'y a plus de création à la première
    connexion (audit A-07 d). Un seul message d'échec, que l'erreur porte sur la classe,
    le prénom ou le code : on ne révèle pas quels élèves existent.
    """
    ip = limitation.adresse_ip(request)
    compte = f"eleve:{corps.code_classe}:{corps.prenom.lower()}"
    limitation.verifier(
        (limitation.par_ip, ip), (limitation.codes_inconnus, ip), (limitation.echecs_code_eleve, compte),
        (limitation.echecs_eleve_par_ip, ip),
    )
    limitation.par_ip.enregistrer(ip)

    classe = session.scalar(select(models.Classe).where(models.Classe.code == corps.code_classe))
    if classe is None:
        limitation.codes_inconnus.enregistrer(ip)  # freine la recherche de codes classe
        limitation.echecs_eleve_par_ip.enregistrer(ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, ECHEC_CONNEXION)
    eleve = session.scalar(
        select(models.Eleve).where(models.Eleve.classe_id == classe.id, func.lower(models.Eleve.prenom) == corps.prenom.lower())
    )
    empreinte = eleve.code_hash if eleve and eleve.code_hash else _code_leurre()  # même durée dans tous les cas
    if not verifier_code_eleve(corps.code_personnel, empreinte) or not (eleve and eleve.code_hash):
        limitation.echecs_code_eleve.enregistrer(compte)
        limitation.echecs_eleve_par_ip.enregistrer(ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, ECHEC_CONNEXION)
    limitation.echecs_code_eleve.effacer(compte)
    if carte_bloquee(eleve):
        raise HTTPException(status.HTTP_403_FORBIDDEN, CARTE_BLOQUEE)
    if not classe.enseignant.actif:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Le compte de ton professeur est suspendu.")
    if classe.archivee_le is not None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, CLASSE_ARCHIVEE)
    version = version_mot_de_passe(eleve.code_hash)
    return JetonEleve(jeton=creer_jeton(ELEVE, eleve.id, settings.duree_jeton_eleve_h, version), eleve=_info(eleve))


CARTE_ANGLAIS = "Cette carte est une carte Boussole Anglais : connecte-toi sur la page élève de Boussole Anglais."


def _carte_anglais(session: SessionDB, identifiant: str, code: str) -> bool:
    eleve = session.scalar(select(models.EleveAnglais).where(func.lower(models.EleveAnglais.identifiant) == identifiant))
    return bool(eleve and eleve.code_hash and verifier_code_eleve(code, eleve.code_hash))


@router.post("/eleves/connexion/identifiant", response_model=JetonEleve)
def connexion_identifiant(corps: ConnexionIdentifiant, request: Request, session: SessionDB) -> JetonEleve:
    """Identifiant + code personnel, tous deux imprimés sur la carte de l'élève (ou lus dans son QR code).

    « Rester connecté » allonge la session pour l'appareil personnel de l'élève. Mêmes protections que
    la connexion par prénom : un seul message d'échec, durée constante, limitation des essais.
    """
    ip = limitation.adresse_ip(request)
    identifiant = normaliser_identifiant(corps.identifiant)
    compte = f"eleve-id:{identifiant}"
    limitation.verifier((limitation.par_ip, ip), (limitation.codes_inconnus, ip), (limitation.echecs_code_eleve, compte), (limitation.echecs_eleve_par_ip, ip))
    limitation.par_ip.enregistrer(ip)

    eleve = session.scalar(select(models.Eleve).where(func.lower(models.Eleve.identifiant) == identifiant))
    empreinte = eleve.code_hash if eleve and eleve.code_hash else _code_leurre()  # même durée dans tous les cas
    if not verifier_code_eleve(corps.code_personnel, empreinte) or not (eleve and eleve.code_hash):
        if eleve is None and _carte_anglais(session, identifiant, corps.code_personnel):
            # Carte PKP Anglais saisie sur la page de maths : on indique la bonne page (seulement avec le bon code,
            # pour ne rien révéler à qui essaie des identifiants).
            raise HTTPException(status.HTTP_409_CONFLICT, CARTE_ANGLAIS)
        if eleve is None:
            limitation.codes_inconnus.enregistrer(ip)  # freine la recherche d'identifiants
        limitation.echecs_code_eleve.enregistrer(compte)
        limitation.echecs_eleve_par_ip.enregistrer(ip)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, ECHEC_IDENTIFIANT)
    limitation.echecs_code_eleve.effacer(compte)
    if carte_bloquee(eleve):
        raise HTTPException(status.HTTP_403_FORBIDDEN, CARTE_BLOQUEE)
    if not eleve.classe.enseignant.actif:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Le compte de ton professeur est suspendu.")
    if eleve.classe.archivee_le is not None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, CLASSE_ARCHIVEE)
    duree_h = settings.duree_jeton_eleve_longue_j * 24 if corps.rester_connecte else settings.duree_jeton_eleve_h
    version = version_mot_de_passe(eleve.code_hash)
    return JetonEleve(jeton=creer_jeton(ELEVE, eleve.id, duree_h, version), eleve=_info(eleve))


@router.get("/eleves/moi", response_model=EleveInfo)
def moi(eleve: EleveCourant) -> EleveInfo:
    return _info(eleve)


@router.get("/eleves/moi/parcours", response_model=list[InscriptionLiee])
def mes_parcours(eleve: EleveCourant, session: SessionDB) -> list[InscriptionLiee]:
    """Toutes les inscriptions de l'élève (celle-ci comprise), reliées par son professeur."""
    autres = inscriptions.liees(session, eleve)
    return [inscriptions.decrire(e, actuelle=e.id == eleve.id) for e in sorted([eleve, *autres], key=lambda e: e.id)]


@router.post("/eleves/moi/parcours/{eleve_id}", response_model=JetonEleve)
def changer_de_parcours(eleve_id: int, eleve: EleveCourant, session: SessionDB) -> JetonEleve:
    """Passe à une autre inscription du même élève : vérifié côté serveur (lien posé par le professeur)."""
    cible = next((e for e in inscriptions.liees(session, eleve) if e.id == eleve_id), None)
    if cible is None or cible.code_hash is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Parcours introuvable.")
    if not cible.classe.enseignant.actif:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Le compte du professeur de cette classe est suspendu.")
    if cible.classe.archivee_le is not None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, CLASSE_ARCHIVEE)
    version = version_mot_de_passe(cible.code_hash)
    return JetonEleve(jeton=creer_jeton(ELEVE, cible.id, settings.duree_jeton_eleve_h, version), eleve=_info(cible))


@router.get("/eleves/moi/progression", response_model=list[ProgressionCompetence])
def ma_progression(eleve: EleveCourant, session: SessionDB) -> list[ProgressionCompetence]:
    return progression_eleve(session, eleve, limiter=True)


@router.get("/eleves/moi/chapitres", response_model=list[ChapitreOuvert])
def mes_chapitres(eleve: EleveCourant, session: SessionDB) -> list[ChapitreOuvert]:
    """Chapitres ouverts par l'enseignant, avec le nombre de questions disponibles."""
    permis = set(ids_ouverts_eleve(session, eleve.classe))
    chapitres = sorted((c for c in eleve.classe.chapitres_proposes if c.id in permis), key=lambda c: c.ordre)
    nb = nb_questions_servables(session, [c.id for c in chapitres])
    return [ChapitreOuvert(id=c.id, code=c.code, titre=c.titre, nb_questions=nb.get(c.id, 0), rubrique=(c.rubrique.value if c.rubrique else None)) for c in chapitres]


@router.get("/eleves/moi/historique", response_model=PageHistorique)
def mon_historique(
    eleve: EleveCourant, session: SessionDB, page: int = 1, erreurs: bool = False, competence_id: int | None = None
) -> PageHistorique:
    """Ce que l'élève a déjà fait : questions, réponses, corrections (questions déjà répondues uniquement)."""
    return historique_reponses(session, eleve, page, erreurs, competence_id)


@router.get("/eleves/moi/competences/{competence_id}/avancement", response_model=AvancementCompetence)
def mon_avancement(competence_id: int, eleve: EleveCourant, session: SessionDB) -> AvancementCompetence:
    """Avancement dans la méthode PKP pour une compétence d'un chapitre ouvert."""
    competence = session.get(models.Competence, competence_id)
    if competence is None or competence.masque or competence.chapitre_id not in ids_ouverts_eleve(session, eleve.classe):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Compétence introuvable.")
    return avancement_competence(session, eleve, competence)


@router.post("/seances", response_model=SeanceInfo, status_code=status.HTTP_201_CREATED)
def demarrer_seance(eleve: EleveCourant, session: SessionDB, corps: SeanceCreation | None = None) -> models.Seance:
    """Démarre une séance sur les chapitres choisis (tous les chapitres ouverts si aucun choix)."""
    refus = permissions.refus_acces_classe(session, eleve.classe)
    if refus:
        raise HTTPException(status.HTTP_403_FORBIDDEN, refus)
    ouverts = {c.id: c for c in eleve.classe.chapitres_proposes if not c.masque and est_apprentissage(c)}
    if not ouverts:
        raise HTTPException(status.HTTP_409_CONFLICT, "Ton professeur n'a pas encore ouvert de chapitre.")
    competences = []
    if corps and corps.competence_ids:
        # Séance ciblée depuis une leçon : les chapitres sont ceux des compétences demandées.
        competences = [session.get(models.Competence, i) for i in dict.fromkeys(corps.competence_ids)]
        if any(c is None or c.masque or c.chapitre_id not in ouverts for c in competences):
            raise HTTPException(422, "Cette compétence n'est pas proposée par ton professeur.")
        choisis = list(dict.fromkeys(c.chapitre_id for c in competences))
    else:
        choisis = list(dict.fromkeys(corps.chapitre_ids)) if corps and corps.chapitre_ids else list(ouverts)
    if any(i not in ouverts for i in choisis):
        raise HTTPException(422, "Ce chapitre n'est pas proposé par ton professeur.")
    seance = models.Seance(
        eleve=eleve, debut=_maintenant(), chapitres=[ouverts[i] for i in choisis], competences=competences,
        difficulte_min=corps.difficulte_min if corps else None, difficulte_max=corps.difficulte_max if corps else None,
    )
    session.add(seance)
    session.commit()
    return seance


def _seance_ouverte(session: SessionDB, seance_id: int, eleve: models.Eleve, verifier_acces: bool = True) -> models.Seance:
    seance = session.get(models.Seance, seance_id)
    if seance is None or seance.eleve_id != eleve.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Séance introuvable.")
    if seance.fin is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Cette séance est terminée.")
    # Révocation d'une classe pilote ou fermeture du domaine : la séance en cours s'arrête aussi (#176).
    # Seule la clôture reste permise (`verifier_acces=False`) : elle ne sert aucun contenu.
    refus = verifier_acces and permissions.refus_acces_classe(session, eleve.classe)
    if refus:
        raise HTTPException(status.HTTP_403_FORBIDDEN, refus)
    return seance


@router.post("/seances/{seance_id}/fin", response_model=SeanceInfo)
def terminer_seance(seance_id: int, eleve: EleveCourant, session: SessionDB) -> models.Seance:
    seance = _seance_ouverte(session, seance_id, eleve, verifier_acces=False)
    seance.fin = _maintenant()
    seance.question_courante = None
    seance.question_servie_le = None
    session.commit()
    return seance


def _candidates(session: SessionDB, seance: models.Seance, eleve: models.Eleve) -> list[Question]:
    """Questions que cette séance peut servir, pour le moteur."""
    # Les colonnes de la question du moteur, sans charger chaque objet entier (correction, gabarit…) :
    # ce serait plus cher que tout le reste de la requête. La question choisie est lue ensuite.
    questions = list(
        session.execute(
            select(
                models.Question.id,
                models.Question.competence_id,
                models.Question.enonce,
                models.Question.type,
                models.Question.solution,
                models.Question.difficulte,
                models.Question.forme,
                models.Question.statut_validation,
                # Colonne JSON : « sans gabarit » y est un null JSON, pas un NULL SQL.
                and_(models.Question.gabarit.is_not(None), cast(models.Question.gabarit, String) != "null").label("variable"),
            )
            .join(models.Competence)
            .join(models.Chapitre)
            .where(
                # Chapitres choisis pour la séance ; séances antérieures : tous les chapitres ouverts.
                models.Chapitre.id.in_([c.id for c in seance.chapitres] or ids_ouverts(eleve.classe)),
                models.Question.archivee.is_(False),
                models.Question.type != TypeQuestion.REDACTION,  # #179 : se rédige dans « Rédaction », jamais en séance
                *filtre_apprentissage(),
                *filtre_validation(),
                *([models.Question.competence_id.in_([c.id for c in seance.competences])] if seance.competences else []),
                *([models.Question.difficulte >= seance.difficulte_min] if seance.difficulte_min else []),
                *([models.Question.difficulte <= seance.difficulte_max] if seance.difficulte_max else []),
            )
        )
    )
    if settings.servir_questions_non_validees:
        questions = validees_en_priorite(session, questions)
    return [
        Question(q.id, q.competence_id, q.enonce, q.type, q.solution, q.difficulte, forme=q.forme, variable=bool(q.variable))
        for q in questions
    ]


@router.get(
    "/seances/{seance_id}/question",
    response_model=QuestionPublique,
    responses={204: {"description": "Rien à proposer : voir /seances/{seance_id}/epuisement."}},
)
def question_suivante(seance_id: int, eleve: EleveCourant, session: SessionDB, revision: bool = False):
    """`revision=true` : l'élève demande à revoir des questions déjà réussies (ticket #26) ; sinon une
    question réussie reste au repos le temps de `ESPACEMENT_REVISION` réponses."""
    seance = _seance_ouverte(session, seance_id, eleve)
    if seance.question_courante is not None:
        return exemplaires.publique(seance.question_courante, seance.tirage_courant)

    candidates = _candidates(session, seance, eleve)
    historique = historique_eleve(session, eleve.id, {q.competence_id for q in candidates})
    choix = choisir_prochaine_question(candidates, historique, espacement=0 if revision else ESPACEMENT_REVISION)
    if choix is None:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    return _servir(session, seance, session.get(models.Question, choix.id))


@router.get("/seances/{seance_id}/epuisement", response_model=Epuisement)
def epuisement(seance_id: int, eleve: EleveCourant, session: SessionDB) -> Epuisement:
    """Pourquoi la séance n'a plus de question : banque vide, ou tout est déjà réussi récemment (l'élève
    peut alors réviser, choisir d'autres chapitres ou terminer : pas de boucle silencieuse)."""
    seance = _seance_ouverte(session, seance_id, eleve)
    candidates = _candidates(session, seance, eleve)
    historique = historique_eleve(session, eleve.id, {q.competence_id for q in candidates})
    au_repos = questions_au_repos(historique) & {q.id for q in candidates}
    return Epuisement(
        motif="toutes-reussies" if candidates else "aucune-question",
        nb_questions=len(candidates),
        nb_au_repos=len(au_repos),
    )


def _servir(session: SessionDB, seance: models.Seance, question: models.Question) -> dict:
    """Pose la question : pour une question à valeurs variables, de nouveaux nombres à chaque fois."""
    seance.question_courante = question
    seance.tirage_courant = exemplaires.nouveau_tirage(question)
    seance.question_servie_le = _maintenant()
    session.commit()
    return exemplaires.publique(question, seance.tirage_courant)


@router.post("/seances/{seance_id}/variante", response_model=QuestionPublique)
def refaire_avec_d_autres_nombres(seance_id: int, corps: DemandeVariante, eleve: EleveCourant, session: SessionDB):
    """Après une réponse, le même exercice avec d'autres nombres : seulement pour la question qui vient
    d'être corrigée dans cette séance, et seulement si elle est à valeurs variables."""
    seance = _seance_ouverte(session, seance_id, eleve)
    derniere = session.scalar(
        select(models.Reponse).where(models.Reponse.seance_id == seance.id).order_by(models.Reponse.id.desc()).limit(1)
    )
    question = derniere.question if derniere else None
    if seance.question_courante is not None or question is None or question.id != corps.question_id:
        raise HTTPException(status.HTTP_409_CONFLICT, "On ne peut refaire que l'exercice qui vient d'être corrigé.")
    if question.gabarit is None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Cet exercice n'a pas de variante : ses valeurs sont fixes.")
    return _servir(session, seance, question)


@router.post("/seances/{seance_id}/reponses", response_model=ResultatReponse)
def repondre(seance_id: int, corps: SoumissionReponse, eleve: EleveCourant, session: SessionDB) -> ResultatReponse:
    seance = _seance_ouverte(session, seance_id, eleve)
    question = seance.question_courante
    if question is None or question.id != corps.question_id:
        raise HTTPException(status.HTTP_409_CONFLICT, "Cette question n'est pas la question en cours.")

    if not corrige_automatiquement(question_vers_domaine(question)) or not est_apprentissage(question.competence.chapitre):
        # Garde-fou (issue #162) : une réponse rédigée ou de diagnostic n'entre jamais dans `reponse` (la maîtrise).
        raise HTTPException(status.HTTP_409_CONFLICT, "Cette question ne se corrige pas en séance d'entraînement.")
    maintenant = _maintenant()
    tirage = seance.tirage_courant
    verdict = verifier(exemplaires.domaine(question, tirage), corps.reponse_donnee)
    correcte = verdict is Verdict.JUSTE
    session.add(
        models.Reponse(
            seance=seance,
            question=question,
            reponse_donnee=corps.reponse_donnee,
            correcte=correcte,
            duree_s=(maintenant - _utc(seance.question_servie_le)).total_seconds(),
            repondu_le=maintenant,
            tirage=tirage,
        )
    )
    seance.question_courante = None
    seance.question_servie_le = None
    seance.tirage_courant = None
    session.commit()

    historique = historique_eleve(session, eleve.id, [question.competence_id])
    return ResultatReponse(
        correcte=correcte,
        solution=exemplaires.solution(question, tirage),
        correction=exemplaires.correction(question, tirage),
        competence=question.competence.libelle,
        competence_id=question.competence_id,
        methodes=[m["titre"] for m in question.competence.methodes or []],
        rappel=question.competence.lecon.resume if question.competence.lecon else None,
        maitrise=calculer_maitrise(historique, question.competence_id),
        maitrisee=est_maitrisee(historique, question.competence_id),
        remarque=(
            f"Ta réponse a la bonne valeur, mais elle n'est pas sous forme {LIBELLES_FORMES[question.forme]}."
            if verdict is Verdict.FORME
            else None
        ),
    )

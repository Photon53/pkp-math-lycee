from typing import Literal

from pydantic import PositiveInt, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

CLE_DEV = "dev-uniquement-a-changer"


# Issue #180 (relecture de la PR #186) : verrou technique des PDF de français. Passé à True par la PR qui livre le
# contrôle renforcé des PDF (#4, `app/controle_pdf.py`), avec ses tests. S'il était faux, PKP_PDF_FRANCAIS_OUVERT
# resterait sans effet et l'API refuserait de démarrer en production avec ce réglage. L'ouverture des PDF de français
# reste soumise à la décision du propriétaire (docs/DEPLOIEMENT.md) : PKP_PDF_FRANCAIS_OUVERT vaut false par défaut.
CONTROLE_PDF_RENFORCE = True


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="PKP_")

    environnement: Literal["dev", "production"] = "dev"
    database_url: str = "sqlite:///./pkp.db"
    cors_origins: list[str] = ["http://localhost:5173"]
    # Clé de signature des jetons. Générer : python -c "import secrets; print(secrets.token_urlsafe(48))"
    secret_key: str = CLE_DEV
    duree_jeton_eleve_h: int = 12
    # « Rester connecté » sur l'appareil personnel de l'élève (travail à la maison).
    duree_jeton_eleve_longue_j: int = 30
    duree_jeton_enseignant_h: int = 8
    duree_jeton_parent_h: int = 12
    # Espace administrateur : session courte (cahier des charges V2, EA2.4).
    duree_jeton_admin_min: int = 30
    # Second facteur des administrateurs. Toujours exigé en production (voir `totp_requis`).
    totp_admin_obligatoire: bool = False

    # Ressources : fichiers PDF, hors de la racine web, servis par l'API après contrôle des droits.
    dossier_fichiers: str = "./fichiers"
    pdf_taille_max_mo: int = 10
    pdf_max_par_enseignant: int = 50
    # Issue #180 (décision du 19/11/2026) : en français, liens seulement pendant le pilote. Les PDF s'ouvriront sur
    # décision du propriétaire, le contrôle renforcé des PDF (#4) étant livré : PKP_PDF_FRANCAIS_OUVERT=true n'a
    # d'effet que si CONTROLE_PDF_RENFORCE est vrai (procédure : docs/DEPLOIEMENT.md).
    pdf_francais_ouvert: bool = False
    # Issue #179 (décision RGPD-2) : rédaction en ligne fermée tant que le responsable, la base légale et
    # l'information des élèves et des parents ne sont pas validés ; PKP_REDACTION_ACTIVE=true pour l'ouvrir.
    redaction_active: bool = False
    redaction_longueur_max: int = 10_000
    # Issue #172 : « Accueil et demandes ». Durée de conservation par file, en jours depuis le dernier traitement, par
    # exemple PKP_ACCUEIL_CONSERVATION_JOURS='{"candidature": 180, "partenariat": 365}'. Aucune durée par défaut :
    # elles sont décidées par le propriétaire (RGPD-3, en attente). Sans durée, une file ne collecte rien (formulaire
    # fermé, saisie refusée) et la purge n'y supprime rien.
    accueil_conservation_jours: dict[Literal["famille", "information", "candidature", "partenariat"], PositiveInt] = {}
    # Issue #171 : formulaire public « Enseigner ou collaborer avec nous ». Fermé par défaut ; ne s'ouvre qu'avec les
    # durées des files candidature et partenariat (démarrage refusé en production sinon).
    collaboration_active: bool = False
    # CV : PDF seulement, contrôlé comme les ressources (#4), dans un dossier privé distinct de `dossier_fichiers`.
    dossier_candidatures: str = "./candidatures"
    cv_taille_max_mo: int = 5
    # Vérifier qu'un lien répond au moment où il est enregistré (désactivé en test).
    verifier_liens: bool = True

    # Limitation des tentatives de connexion, sur une fenêtre glissante.
    # Les plafonds par IP restent larges : une classe entière sort souvent par
    # la même adresse (réseau du lycée).
    connexion_fenetre_min: int = 15
    connexion_enseignant_max_echecs: int = 5  # par compte enseignant
    connexion_eleve_max_codes_inconnus: int = 30  # codes classe inconnus, par IP
    connexion_eleve_max_echecs_code: int = 5  # codes personnels faux, par compte élève
    # Échecs de connexion élève, par adresse (SEC-D5, #87) : les identifiants « Lina1 » se devinent, le code reste
    # le seul secret. 60 / 15 min laisse de la marge à une classe de 35 derrière la même adresse.
    connexion_eleve_max_echecs_par_ip: int = 60
    connexion_max_par_ip: int = 300  # toutes tentatives confondues

    # Banque de questions : servir aussi les questions pas encore validées par un enseignant.
    # Même à True, une compétence qui a au moins une question validée ne sert plus que celles-là.
    # En production, le choix doit être explicite (PKP_SERVIR_QUESTIONS_NON_VALIDEES dans .env).
    servir_questions_non_validees: bool = True

    # Prévalidation IA (ticket #48) : jetons du compte de service, à durée limitée, et plafonds d'usage.
    service_ia_duree_max_j: int = 90
    service_ia_requetes_par_minute: int = 60
    prevalidation_ia_max_par_lot: int = 50

    # RGPD : un élève sans activité depuis ce délai est supprimé par la purge.
    retention_jours: int = 365

    @property
    def production(self) -> bool:
        return self.environnement == "production"

    @property
    def totp_requis(self) -> bool:
        return self.production or self.totp_admin_obligatoire

    @model_validator(mode="before")
    @classmethod
    def _choix_vide_non_fait(cls, valeurs):
        """docker-compose transmet une valeur vide quand .env ne la définit pas : ce n'est pas un choix."""
        if isinstance(valeurs, dict) and valeurs.get("servir_questions_non_validees") == "":
            valeurs = {k: v for k, v in valeurs.items() if k != "servir_questions_non_validees"}
        return valeurs

    @model_validator(mode="after")
    def _verifier_production(self) -> "Settings":
        """En production, l'API refuse de démarrer avec une configuration dangereuse
        (pydantic transforme la ValueError en ValidationError au chargement)."""
        if not self.production:
            return self
        problemes = []
        if self.secret_key == CLE_DEV or len(self.secret_key) < 32:
            problemes.append("PKP_SECRET_KEY doit être définie (32 caractères minimum, aléatoire).")
        if any("localhost" in o or o == "*" for o in self.cors_origins):
            problemes.append("PKP_CORS_ORIGINS ne doit contenir que le domaine public du site.")
        elif any(not o.startswith("https://") for o in self.cors_origins):
            problemes.append("PKP_CORS_ORIGINS : origines en https:// uniquement.")
        if self.database_url.startswith("sqlite"):
            problemes.append("PKP_DATABASE_URL doit pointer vers PostgreSQL en production.")
        if self.pdf_francais_ouvert and not CONTROLE_PDF_RENFORCE:
            problemes.append(
                "PKP_PDF_FRANCAIS_OUVERT ne peut pas être activée : le contrôle renforcé des PDF (#4) n'est pas livré."
            )
        if self.collaboration_active and not {"candidature", "partenariat"} <= set(self.accueil_conservation_jours):
            problemes.append(
                "PKP_COLLABORATION_ACTIVE exige les durées « candidature » et « partenariat » dans "
                "PKP_ACCUEIL_CONSERVATION_JOURS (décision du propriétaire, RGPD-3) : rien n'est collecté sans durée."
            )
        if "servir_questions_non_validees" not in self.model_fields_set:
            problemes.append(
                "PKP_SERVIR_QUESTIONS_NON_VALIDEES doit être choisie explicitement : true pendant la relecture "
                "de la banque (les élèves voient des questions non relues), false ensuite."
            )
        if problemes:
            raise ValueError("Configuration de production invalide :\n- " + "\n- ".join(problemes))
        return self


settings = Settings()

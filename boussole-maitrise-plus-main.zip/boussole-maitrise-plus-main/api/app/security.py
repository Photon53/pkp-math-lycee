"""Hachage des mots de passe enseignant et jetons d'accès signés.

Les élèves n'ont pas de mot de passe : ils se connectent avec leur identifiant (ou prénom + code classe)
et le code personnel distribué par l'enseignant.
Bibliothèque standard uniquement (scrypt, HMAC-SHA256).
"""

import base64
import hashlib
import hmac
import re
import secrets
import threading
import time
import unicodedata

from app.config import settings

# Coût scrypt : recommandation OWASP (Password Storage Cheat Sheet) N = 2^17, r = 8, p = 1,
# soit 128 Mo de mémoire par hachage (audit A-06). Les paramètres sont enregistrés dans
# chaque empreinte : une empreinte plus faible est re-hachée à la connexion (doit_rehacher).
_N, _R, _P = 2**17, 8, 1
# Python limite scrypt à 32 Mo par défaut : on autorise jusqu'à 2^18 (256 Mo). Une empreinte
# demandant davantage est refusée plutôt que de laisser saturer la mémoire.
_MEMOIRE_MAX = 300 * 1024 * 1024
# Au plus 2 hachages simultanés (≈ 256 Mo) : sans cette borne, une rafale de connexions
# parallèles (jusqu'à 40 dans le pool de threads d'uvicorn) réclamerait ≈ 5 Go.
_CALCULS_SIMULTANES = threading.BoundedSemaphore(2)


def _b64(donnees: bytes) -> str:
    return base64.urlsafe_b64encode(donnees).decode().rstrip("=")


def _deb64(texte: str) -> bytes:
    return base64.urlsafe_b64decode(texte + "=" * (-len(texte) % 4))


def _scrypt(mot_de_passe: str, sel: bytes, n: int, r: int, p: int) -> bytes:
    with _CALCULS_SIMULTANES:
        return hashlib.scrypt(mot_de_passe.encode(), salt=sel, n=n, r=r, p=p, maxmem=_MEMOIRE_MAX)


def _hacher(secret: str, n: int) -> str:
    sel = secrets.token_bytes(16)
    return f"scrypt${n}${_R}${_P}${_b64(sel)}${_b64(_scrypt(secret, sel, n, _R, _P))}"


def hacher_mot_de_passe(mot_de_passe: str) -> str:
    return _hacher(mot_de_passe, _N)


# --- Code personnel des élèves (audit A-07, décision D1) ----------------------
# 6 caractères sans 0/O ni 1/I/L (recopiés à la main) : 31^6 ≈ 887 millions de codes.
# Coût de hachage modéré (4 Mo, quelques ms) : 35 élèves doivent pouvoir se connecter
# ensemble ; la protection contre les essais vient du blocage par compte (limitation.py).
ALPHABET_CODE = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
LONGUEUR_CODE_ELEVE = 6
_N_CODE = 2**12


def generer_code_eleve() -> str:
    return "".join(secrets.choice(ALPHABET_CODE) for _ in range(LONGUEUR_CODE_ELEVE))


# Identifiant de connexion. Ancien format (« ines-k7m4 », comptes émis avant RGPD-1) : prénom + tiret + 4
# caractères aléatoires ; il reste valable. Nouveau format (décision RGPD-1, #87) : prénom sans accent suivi d'un
# numéro, sans séparateur (« Ines1 »), tenu par un compteur jamais remis à zéro (enfants.identifiant_libre).
# Il n'est pas secret (affiché, imprimé sur la carte) : c'est le code personnel qui protège.
ALPHABET_IDENTIFIANT = "23456789abcdefghjkmnpqrstuvwxyz"
LONGUEUR_IDENTIFIANT = 40
# Lettres acceptées dans un prénom mais sans décomposition Unicode : NFKD les ferait disparaître.
_TRANSLITERATION = str.maketrans({"æ": "ae", "Æ": "Ae", "ø": "o", "Ø": "O", "ß": "ss", "ð": "d", "Ð": "D",
                                  "þ": "th", "Þ": "Th", "œ": "oe", "Œ": "Oe"})


def sans_accents(texte: str) -> str:
    """« Léa » → « Lea », « Æsa » → « Aesa » : lettres d'origine gardées, accents retirés, casse conservée."""
    texte = unicodedata.normalize("NFKD", texte.translate(_TRANSLITERATION))
    return "".join(c for c in texte if not unicodedata.combining(c))


def base_identifiant(prenom: str) -> str:
    """Base du nouvel identifiant : le prénom sans accents, sans espace, tiret ni apostrophe, casse conservée
    (« Jean-Pierre » → « JeanPierre », « N'Golo » → « NGolo »). Vide si le prénom n'a aucune lettre."""
    return re.sub(r"[^A-Za-z]+", "", sans_accents(prenom))


def cle_identifiant(identifiant: str) -> str:
    """Forme de comparaison : « Léa1 », « lea1 » et « LEA1 » désignent le même identifiant (anciens compris)."""
    return sans_accents(identifiant.strip()).lower()


def generer_identifiant(prenom: str) -> str:
    """Ancien format, gardé pour les comptes de démonstration (« lina-demo ») : jamais pour un nouveau compte."""
    base = base_identifiant(prenom).lower()[:20] or "eleve"
    return f"{base}-{''.join(secrets.choice(ALPHABET_IDENTIFIANT) for _ in range(4))}"


def normaliser_identifiant(identifiant: str) -> str:
    return cle_identifiant(identifiant)


def normaliser_code(code: str) -> str:
    """« k7m 4qp », « K7M-4QP » et « K7M4QP » désignent le même code."""
    return "".join(c for c in code.upper() if c not in " -")


# Code choisi par un parent pour son enfant : plus long qu'un code tiré au hasard, car un code choisi
# est plus facile à deviner. Lettres et chiffres, sans distinction de casse (comme les codes générés).
LONGUEUR_CODE_CHOISI_MIN, LONGUEUR_CODE_CHOISI_MAX = 8, 16


def probleme_code_choisi(code: str, interdits: tuple[str, ...] = ()) -> str | None:
    """Message d'erreur si le code (déjà normalisé) ne respecte pas les règles, sinon None."""
    if not LONGUEUR_CODE_CHOISI_MIN <= len(code) <= LONGUEUR_CODE_CHOISI_MAX:
        return f"Le code doit compter de {LONGUEUR_CODE_CHOISI_MIN} à {LONGUEUR_CODE_CHOISI_MAX} caractères."
    if not re.fullmatch(r"[A-Z0-9]+", code):
        return "Le code ne peut contenir que des lettres (sans accent) et des chiffres."
    if not re.search(r"[A-Z]", code) or not re.search(r"[0-9]", code):
        return "Le code doit contenir au moins une lettre et un chiffre."
    if len(set(code)) < 4:
        return "Le code doit contenir au moins 4 caractères différents."
    if code in "0123456789" or code in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" or "12345678" in code or "AZERTY" in code:
        return "Ce code est trop facile à deviner."
    if any(mot and mot in code for mot in interdits):
        return "Le code ne doit pas contenir le prénom ni l'identifiant de l'élève."
    return None


def hacher_code_eleve(code: str) -> str:
    return _hacher(normaliser_code(code), _N_CODE)


def verifier_code_eleve(code: str, stocke: str) -> bool:
    return verifier_mot_de_passe(normaliser_code(code), stocke)


def verifier_mot_de_passe(mot_de_passe: str, stocke: str) -> bool:
    try:
        algo, n, r, p, sel, empreinte = stocke.split("$")
        if algo != "scrypt":
            return False
        calcul = _scrypt(mot_de_passe, _deb64(sel), int(n), int(r), int(p))
    except (ValueError, MemoryError):
        return False
    return hmac.compare_digest(calcul, _deb64(empreinte))


def doit_rehacher(stocke: str) -> bool:
    """Vrai si l'empreinte a été calculée avec des paramètres plus faibles que les actuels."""
    try:
        _, n, r, p, _, _ = stocke.split("$")
        return (int(n), int(r), int(p)) < (_N, _R, _P)
    except ValueError:
        return True


def version_mot_de_passe(empreinte_stockee: str) -> str:
    """Empreinte courte du hachage d'un secret (mot de passe enseignant, code personnel élève),
    embarquée dans les jetons. Changer le secret change cette valeur et invalide tous les jetons
    émis avant (audit A-09, et régénération d'un code élève)."""
    return hashlib.sha256(empreinte_stockee.encode()).hexdigest()[:16]


def creer_jeton(role: str, sujet_id: int, duree_h: float, version: str = "") -> str:
    """Jeton `charge.signature` où charge = « role:id:expiration:version »."""
    charge = f"{role}:{sujet_id}:{int(time.time() + duree_h * 3600)}:{version}".encode()
    return f"{_b64(charge)}.{_b64(_signer(charge))}"


def lire_jeton(jeton: str, role_attendu: str) -> tuple[int, str] | None:
    """Renvoie (id du sujet, version) si le jeton est authentique, non expiré et du bon rôle."""
    try:
        charge_b64, signature_b64 = jeton.split(".")
        charge = _deb64(charge_b64)
        if not hmac.compare_digest(_signer(charge), _deb64(signature_b64)):
            return None
        role, sujet_id, expiration, version = charge.decode().split(":")
        if role != role_attendu or int(expiration) < time.time():
            return None
        return int(sujet_id), version
    except (ValueError, UnicodeDecodeError):
        return None


# --- Second facteur des administrateurs (TOTP, RFC 6238) -----------------------
# Compatible avec les applications d'authentification courantes : SHA-1, 6 chiffres, 30 s.
_TOTP_PAS_S = 30
_TOTP_CHIFFRES = 6


def generer_secret_totp() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode()


def code_totp(secret: str, instant: float | None = None) -> str:
    compteur = int((time.time() if instant is None else instant) // _TOTP_PAS_S)
    cle = base64.b32decode(secret.upper() + "=" * (-len(secret) % 8))
    mac = hmac.new(cle, compteur.to_bytes(8, "big"), hashlib.sha1).digest()
    decalage = mac[-1] & 0x0F
    valeur = int.from_bytes(mac[decalage : decalage + 4], "big") & 0x7FFFFFFF
    return str(valeur % 10**_TOTP_CHIFFRES).zfill(_TOTP_CHIFFRES)


def verifier_totp(secret: str, code: str, instant: float | None = None) -> bool:
    """Accepte le pas courant et ses deux voisins (décalage d'horloge du téléphone)."""
    maintenant = time.time() if instant is None else instant
    code = code.replace(" ", "")
    return any(
        hmac.compare_digest(code_totp(secret, maintenant + d * _TOTP_PAS_S), code) for d in (-1, 0, 1)
    )


def uri_totp(secret: str, email: str) -> str:
    """À transformer en QR code ou à saisir dans l'application d'authentification."""
    return f"otpauth://totp/Boussole:{email}?secret={secret}&issuer=Boussole"


def hacher_mot_de_passe_provisoire(provisoire: str) -> str:
    """Mot de passe provisoire tiré au hasard (16 caractères parmi 54, environ 92 bits) : un coût de hachage
    modéré suffit, la lenteur ne protège que les secrets choisis par un humain. Sans cela, importer 500 élèves
    (375 comptes parents) prenait plus de 8 minutes (mesure V3, Lot 0). L'empreinte est re-hachée au coût
    complet à la première connexion (`doit_rehacher`), puis remplacée par le mot de passe choisi."""
    return _hacher(provisoire, _N_CODE)


def generer_mot_de_passe_provisoire() -> str:
    # 16 caractères sans caractères ambigus : recopié à la main par le professeur.
    return "".join(secrets.choice(ALPHABET_CODE + "abcdefghjkmnpqrstuvwxyz") for _ in range(16))


def _signer(charge: bytes) -> bytes:
    return hmac.new(settings.secret_key.encode(), charge, hashlib.sha256).digest()

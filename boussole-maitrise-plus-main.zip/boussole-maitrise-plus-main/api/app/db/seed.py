"""Données de démonstration. Usage, depuis `api/` : `python -m app.db.seed`

1. Importe le contenu pédagogique de `contenu/` (chapitres, cours, questions).
2. Crée, si absents, un enseignant, des classes, des élèves et un historique de réponses.
Idempotent : relancer ne duplique rien.

Compte enseignant de démo (local uniquement) :
    email        : demo@pkp.test
    mot de passe : valeur de PKP_DEMO_MOT_DE_PASSE, sinon « demo-pkp-2026 »

Compte administrateur de démo (local uniquement, sans second facteur hors production) :
    email        : admin@pkp.test
    mot de passe : le même que l'enseignant de démo

Codes personnels des élèves de démo (local uniquement) : voir CODES_DEMO ci-dessous,
par exemple Lina / 2NDE-A-DEMO / PKP222, ou, avec l'identifiant de connexion, lina-demo / PKP222.
"""

import os
from datetime import UTC, datetime, timedelta

from pkp_engine import Niveau, corriger
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import anglais_contenu, contenu, permissions
from app.db import models
from app.db.conversions import question_vers_domaine
from app.progression import chapitres_du_programme
from app.referentiel import Role, domaine_maths, parcours_par_defaut
from app.security import generer_identifiant, hacher_code_eleve, hacher_mot_de_passe

EMAIL_DEMO = "demo@pkp.test"
EMAIL_ADMIN_DEMO = "admin@pkp.test"
EMAIL_ANGLAIS_DEMO = "anglais@pkp.test"

# Codes fixes pour pouvoir tester en local ; en vrai, l'enseignant les génère (aléatoires).
CODES_DEMO = {"Lina": "PKP222", "Yanis": "PKP333", "Inès": "PKP444", "Hugo": "PKP555", "Emma": "PKP666"}


def identifiant_demo(prenom: str) -> str:
    """Identifiant de connexion des élèves de démo : « lina-demo », « ines-demo »…"""
    return generer_identifiant(prenom).rsplit("-", 1)[0] + "-demo"

CLASSES = [
    ("2NDE-A-DEMO", Niveau.SECONDE, ["Lina", "Yanis", "Inès"]),
    ("1RE-B-DEMO", Niveau.PREMIERE, ["Hugo"]),
    ("TLE-C-DEMO", Niveau.TERMINALE, ["Emma"]),
]

# (prénom, [(code question, réponse saisie)])
SEANCES = [
    ("Lina", [("2NDE-FRAC-01", "5/6"), ("2NDE-FRAC-02", "1/5"), ("2NDE-DEV-01", "x²+6x+9"),
              ("2NDE-DEV-03", "2x²+7x+4"), ("2NDE-EQ1-01", "5")]),
    ("Yanis", [("2NDE-FRAC-01", "2/5"), ("2NDE-FRAC-01", "5/6")]),
]


class DemoInterdite(RuntimeError):
    """Données de démonstration demandées en production : comptes et codes connus de tous (#116)."""


def charger_demo(session: Session) -> bool:
    """Charge le contenu puis les données de démo. Renvoie False si la démo existait déjà.
    Refusé en production : mots de passe et codes de la démo sont publiés dans ce fichier (#116)."""
    from app.config import settings

    if settings.production:
        raise DemoInterdite("Données de démonstration refusées en production (PKP_ENVIRONNEMENT=production).")
    contenu.importer(session, contenu.charger())
    anglais_contenu.importer_seances(session)  # soumises à validation : aucun élève ne les voit encore
    mot_de_passe = os.environ.get("PKP_DEMO_MOT_DE_PASSE", "demo-pkp-2026")

    # Ajouté à part : une base de démo antérieure à la V2 reçoit aussi son administrateur.
    if not session.scalar(select(models.Enseignant).where(models.Enseignant.email == EMAIL_ADMIN_DEMO)):
        admin = models.Enseignant(
            nom="Administrateur Démo", email=EMAIL_ADMIN_DEMO, role=Role.ADMIN,
            mot_de_passe_hash=hacher_mot_de_passe(mot_de_passe),
        )
        session.add(admin)
        # Comme la migration 0023 pour les administrateurs existants : professeur et validateur de Maths lycée.
        permissions.appliquer(session, admin, [
            permissions.Portee(permissions.PROFESSEUR, permissions.MATHS_LYCEE),
            permissions.Portee(permissions.VALIDATEUR, permissions.MATHS_LYCEE),
        ], None)
        session.commit()

    # Professeur d'anglais seul : n'a accès qu'à l'espace /anglais (ajouté à part, comme l'administrateur).
    if not session.scalar(select(models.Enseignant).where(models.Enseignant.email == EMAIL_ANGLAIS_DEMO)):
        anglais = models.Enseignant(
            nom="Professeur d'anglais Démo", email=EMAIL_ANGLAIS_DEMO, mot_de_passe_hash=hacher_mot_de_passe(mot_de_passe),
        )
        session.add(anglais)
        permissions.appliquer(session, anglais, [
            permissions.Portee(permissions.PROFESSEUR, permissions.ANGLAIS_COLLEGE),
            permissions.Portee(permissions.VALIDATEUR, permissions.ANGLAIS_COLLEGE),
        ], None)
        session.commit()

    if session.scalar(select(models.Enseignant).where(models.Enseignant.email == EMAIL_DEMO)):
        return False

    enseignant = models.Enseignant(
        nom="Enseignant Démo",
        email=EMAIL_DEMO,
        mot_de_passe_hash=hacher_mot_de_passe(mot_de_passe),
    )
    session.add(enseignant)
    permissions.appliquer(session, enseignant, [permissions.Portee(permissions.PROFESSEUR, permissions.MATHS_LYCEE)], None)

    eleves: dict[str, models.Eleve] = {}
    for code, niveau, prenoms in CLASSES:
        classe = models.Classe(
            code=code, niveau=niveau, parcours=parcours_par_defaut(niveau), enseignant=enseignant,
            domaine_code=domaine_maths(niveau),
        )
        session.add(classe)
        classe.chapitres_proposes = chapitres_du_programme(session, classe)
        for prenom in prenoms:
            eleves[prenom] = models.Eleve(
                prenom=prenom, classe=classe, code_hash=hacher_code_eleve(CODES_DEMO[prenom]), identifiant=identifiant_demo(prenom)
            )
            session.add(eleves[prenom])
    session.flush()

    instant = datetime.now(UTC) - timedelta(days=1)
    for prenom, saisies in SEANCES:
        seance = models.Seance(eleve=eleves[prenom], debut=instant)
        session.add(seance)  # avant les requêtes : leur autoflush doit trouver la séance en session
        for code_question, saisie in saisies:
            question = session.scalar(select(models.Question).where(models.Question.code == code_question))
            instant += timedelta(minutes=1)
            seance.reponses.append(
                models.Reponse(
                    question=question,
                    reponse_donnee=saisie,
                    correcte=corriger(question_vers_domaine(question), saisie),
                    duree_s=45.0,
                    repondu_le=instant,
                )
            )
        seance.fin = instant

    session.commit()
    return True


def main() -> None:
    from app.db.session import SessionLocale

    with SessionLocale() as session:
        try:
            print("Données de démo chargées." if charger_demo(session) else "Contenu à jour, démo déjà présente.")
        except DemoInterdite as exc:
            raise SystemExit(str(exc)) from exc


if __name__ == "__main__":
    main()
